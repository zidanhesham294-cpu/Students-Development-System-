
# SDS → Lovable Cloud Migration + Teacher Role

Cloud is now enabled. This plan replaces every localStorage store with live cloud tables, adds real-time cross-device sync, and builds the full Teacher role (auth, roster, attendance codes, HISTORY) plus the student-side attendance portal.

## 1. Database schema

New tables in `public` (all with `GRANT` + RLS + realtime enabled):

- `students` — 573 rows, one-time seeded from `studentsData.js` (name, admin_id, username, password_hash-as-plaintext for now, points, zone, gpa, attendance, subjects jsonb).
- `behavioral_logs` — student_id, delta, reason, created_at.
- `teachers` — name, username (`TEA-SDS-xxxx`), password.
- `admins` — seeded row for `ZIDAN-SDS-2026 / 1755833`.
- `teacher_roster` — teacher_id + student_id (many-to-many roster).
- `attendance_sessions` — teacher_id, name, code (6 digits), is_active, created_at, closed_at.
- `attendance_records` — session_id, student_id, status (`present`/`absent`), marked_at.
- `active_sessions` — username, role, last_seen (for "النشطون الآن").

Realtime is enabled on `students`, `behavioral_logs`, `attendance_sessions`, `attendance_records`, `active_sessions`.

## 2. Auth model

The existing UI uses username/password, not email. We keep that UX:

- Login is handled by a `login` server function that verifies credentials against `students` / `teachers` / `admins` and returns a signed session token (stored in localStorage as `sds.session`).
- All privileged writes (admin points/logs edits, teacher session create/save, student attendance submit) go through server functions that verify the session token and role before writing with `supabaseAdmin`.
- Public reads (students list, active session code lookup, roster) use narrow `TO anon` SELECT policies so realtime subscriptions work from the browser without a Supabase auth session. Password columns are never selected on the client — a `students_public` view exposes only safe columns.

Rationale: adding Supabase Auth users for 573 students would require synthetic emails and a large seed; the app already uses custom credentials.

## 3. Realtime wiring

Each screen replaces its localStorage reads with a Supabase query + a `postgres_changes` subscription (mounted in `useEffect`, torn down on unmount):

- Student dashboard/points ring → subscribes to its own `students` row + its `behavioral_logs`.
- Admin dashboard → subscribes to `students` (all), `active_sessions`.
- Teacher ACTIVE tab → subscribes to `attendance_records` for the current session; roster rows flip red→green live.
- Student ACTIVE portal → subscribes to `attendance_sessions` (own teacher's active session) to lock input after teacher clicks حفظ.

`adminStore.ts` is rewritten to be a thin async wrapper over Supabase; `useLiveStudent` re-implements using a channel instead of `subscribeState`.

## 4. Teacher role (new)

- Login tab "معلم" with `TEA-SDS-xxxx` format check; gate at login server fn so admin/student creds fail on this tab and vice-versa.
- New route `src/routes/teacher.tsx` with three tabs (STUDENTS / ACTIVE / HISTORY) matching the spec:
  - **STUDENTS**: `+` opens picker modal over all 573; checked rows persist to `teacher_roster`. Each row has an eye icon opening a read-only profile modal (reuses admin's `StudentProfileModal`, no edit controls).
  - **ACTIVE**: session name input, WIFI card that inserts a new `attendance_sessions` row with a random 6-digit code (unique among active sessions); shows live counters and roster with red-X / green-check flipping via realtime; حفظ closes the session and resets UI.
  - **HISTORY**: lists closed sessions for this teacher; click expands the frozen roster matrix.
- Admin dashboard gets a small "المعلمون" management card to create/delete teacher accounts.

## 5. Student ACTIVE portal

`src/routes/dashboard.active.tsx` gets:
- Input "أدخل كود الحضور الحالي" that calls a `submitAttendance` server fn (validates code against active `attendance_sessions`, inserts/updates `attendance_records`, returns success).
- Success banner "تم تسجيل الحضور بنجاح" and locked input for that session.
- HISTORY timeline below listing this student's `attendance_records` grouped by session, showing `حاضر`/`غائب` and date.

## 6. Preserved UI

No visual changes to: metallic Gold/Shiny Gold ring, admin grid layout, luxury "ZIDAN" gradient header, tab-based role gates, glassmorphism, Arabic typography. "HISTORY" nomenclature stays. Attendance card on student dashboard keeps its existing tile styling.

## Technical notes

- Seed migration inserts all 573 students in a single `INSERT ... SELECT FROM (VALUES ...)` chunked statement + one admin row + one teacher row.
- Password column is plaintext (matching current design); documented as school-internal.
- Session token: HMAC of `{username, role, exp}` signed with an auto-generated `SDS_SESSION_SECRET` server-side.
- `studentsData.js` is deleted after seeding; all reads become cloud reads. `src/lib/adminStore.ts` becomes cloud-backed; the `useLiveStudent`, `useActiveHeartbeat`, and admin store subscribe helpers are rewritten around Supabase channels.
- Files touched/added: migration + seed insert, `src/lib/session.ts` (new), `src/lib/session.functions.ts` (login/logout/heartbeat/admin ops/teacher ops/attendance ops server fns), `src/lib/adminStore.ts` (rewritten), `src/hooks/useLiveStudent.ts` + `useActiveHeartbeat.ts` (rewritten), `src/routes/index.tsx` (login), `src/routes/admin.tsx`, `src/routes/dashboard.*`, `src/routes/teacher.tsx` (new), `src/routes/teacher.*.tsx` for the three tabs, `src/routeTree.gen.ts` regenerates automatically.

## Scope check

This is a large change (roughly 15+ files, one big schema migration, one large seed insert). Approving this plan means I will apply the migration, seed all 573 students, and rewrite the client + auth in one pass. Existing browser-local point overrides will be discarded per your earlier answer.

Approve to proceed, or tell me what to adjust.
