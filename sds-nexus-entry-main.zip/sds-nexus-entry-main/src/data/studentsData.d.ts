declare module "@/data/studentsData.js" {
  const students: Array<{
    name: string;
    id: string;
    username: string;
    password: string;
    points: number;
    zone: string;
    gpa: number | null;
    attendance: number;
  }>;
  export default students;
}
