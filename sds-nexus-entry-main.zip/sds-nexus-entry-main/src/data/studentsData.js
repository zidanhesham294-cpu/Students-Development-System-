// Auto-generated from SDS_Students_Database.xlsx — do not truncate.
// 570 student records.

const students = [
  {
    "name": "آلاء صبحى أحمد الشوادفى على ابوزید",
    "id": "252100001",
    "username": "sds-2026-4264",
    "password": "as314264",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "أحمد أیمن محمد ابراھیم سلامھ",
    "id": "252100002",
    "username": "sds-2026-2158",
    "password": "aa302158",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "أحمد ابراھیم رمضان محمد سلیمان",
    "id": "252100003",
    "username": "sds-2026-8619",
    "password": "aa308619",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "أحمد خالد عطاالله محمد مرسى",
    "id": "252100004",
    "username": "sds-2026-2838",
    "password": "ak302838",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "أحمد سامح محمد سلیمان عبد الله",
    "id": "252100005",
    "username": "sds-2026-8736",
    "password": "as318736",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ابانوب حازم منیر شاكر قلدس",
    "id": "252100013",
    "username": "sds-2026-9092",
    "password": "ah309092",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ابانوب مجدى عوض الله عوض بخیت",
    "id": "252101158",
    "username": "sds-2026-0979",
    "password": "am300979",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ابراھیم أحمد ابراھیم رزق أحمد",
    "id": "252100015",
    "username": "sds-2026-4414",
    "password": "aa314414",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ابراھیم السید محمد على على حسن",
    "id": "252101159",
    "username": "sds-2026-4256",
    "password": "aa304256",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ابراھیم سامح ابراھیم الدسوقي محمد على منصور",
    "id": "252100018",
    "username": "sds-2026-3114",
    "password": "as303114",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ابراھیم صلاح ابراھیم حسن خلیل",
    "id": "252100020",
    "username": "sds-2026-1575",
    "password": "as301575",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ابراھیم عبدالله محمد عتریس عبدالنبى",
    "id": "252100021",
    "username": "sds-2026-0515",
    "password": "aa900515",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ابراھیم محمد ابراھیم عبدالرحمن ابراھیم",
    "id": "252100022",
    "username": "sds-2026-2732",
    "password": "am302732",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ابراھیم محمد ابراھیم محمد ابراھیم",
    "id": "252100023",
    "username": "sds-2026-0714",
    "password": "am800714",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ابراھیم محمود كامل خلیل الدمرداش",
    "id": "252100025",
    "username": "sds-2026-5033",
    "password": "am305033",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احلام مصطفى السید على عزب",
    "id": "252100026",
    "username": "sds-2026-0662",
    "password": "am900662",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد ابراھیم احمد ابراھیم احمد",
    "id": "252101093",
    "username": "sds-2026-1176",
    "password": "aa301176",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد ابراھیم محمد ابراھیم ندا",
    "id": "252100027",
    "username": "sds-2026-0297",
    "password": "aa200297",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد ابراھیم محمد عبدالقادر یس",
    "id": "252100028",
    "username": "sds-2026-0613",
    "password": "aa300613",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد ابراھیم ناھض عقیل",
    "id": "252100029",
    "username": "sds-2026-1017",
    "password": "aa101017",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد اشرف محمد سعدالدین الفولى",
    "id": "252100031",
    "username": "sds-2026-1693",
    "password": "aa301693",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد السید عبدالعال على حسن",
    "id": "252100034",
    "username": "sds-2026-1371",
    "password": "aa801371",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد السید محمود السید الزنفلى",
    "id": "252100036",
    "username": "sds-2026-3379",
    "password": "aa343379",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد ایمن حسن السید احمد حسن",
    "id": "252100038",
    "username": "sds-2026-0611",
    "password": "aa310611",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد ثروت على محمد على",
    "id": "252100042",
    "username": "sds-2026-1793",
    "password": "at301793",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد ثروت محمد عبده احمد",
    "id": "252101146",
    "username": "sds-2026-1594",
    "password": "at301594",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد جلال حسن عبده البنا",
    "id": "252100043",
    "username": "sds-2026-0913",
    "password": "aj500913",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد جمال محمد الشحات احمد ابو العنین",
    "id": "252100044",
    "username": "sds-2026-2314",
    "password": "aj302314",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد جمیل عبداللطیف محمد ابراھیم",
    "id": "252100045",
    "username": "sds-2026-5238",
    "password": "aj305238",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد حسن فتحي ابوالمجد محمد",
    "id": "252100047",
    "username": "sds-2026-3314",
    "password": "ah353314",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد خالد محمد احمد اسماعیل",
    "id": "252100049",
    "username": "sds-2026-0777",
    "password": "ak300777",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد رضا محمد الشحات حسن غانم",
    "id": "252100050",
    "username": "sds-2026-2638",
    "password": "ar902638",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد زكى الصاوى الھادى محمد",
    "id": "252101096",
    "username": "sds-2026-3233",
    "password": "az303233",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد سعید على محمد خلیل",
    "id": "252100052",
    "username": "sds-2026-3718",
    "password": "as303718",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد شحتھ علي سلامھ حسن",
    "id": "252100053",
    "username": "sds-2026-3256",
    "password": "as303256",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد صابر محمد على الرفاعى",
    "id": "252100054",
    "username": "sds-2026-1015",
    "password": "as201015",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد صلاح الدین محمد احمد",
    "id": "252100056",
    "username": "sds-2026-0394",
    "password": "as500394",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد طارق محمد السید ابراھیم",
    "id": "252100057",
    "username": "sds-2026-0873",
    "password": "at300873",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد عاطف محمد حسن مغنم",
    "id": "252101118",
    "username": "sds-2026-0457",
    "password": "aa900457",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد عباس عبدالفتاح عباس على",
    "id": "252100060",
    "username": "sds-2026-1515",
    "password": "aa901515",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد عبد الفتاح محمد ابو الفتوح عبد الحمید",
    "id": "252101155",
    "username": "sds-2026-1436",
    "password": "aa301436",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد عصام شعبان عطا السید",
    "id": "252100061",
    "username": "sds-2026-5739",
    "password": "aa305739",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد علاء نمر عطوان",
    "id": "252100062",
    "username": "sds-2026-8392",
    "password": "aa908392",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد على احمد على ابوعوف",
    "id": "252100063",
    "username": "sds-2026-0434",
    "password": "aa900434",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد على شحاتھ ھاشم سالم",
    "id": "252100064",
    "username": "sds-2026-3853",
    "password": "aa323853",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد عوض السید عطیھ عبدالعاطى",
    "id": "252100066",
    "username": "sds-2026-2157",
    "password": "aa352157",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد فتحي ابو الحسن حسن اسماعیل",
    "id": "252100067",
    "username": "sds-2026-0638",
    "password": "af900638",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد ابراھیم الدسوقي محمد محمد الشناط",
    "id": "252100070",
    "username": "sds-2026-0173",
    "password": "am300173",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد ابراھیم محمد محمد",
    "id": "252100071",
    "username": "sds-2026-0731",
    "password": "am900731",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد اسماعیل على عبدالعال الشربینى",
    "id": "252100074",
    "username": "sds-2026-3911",
    "password": "am303911",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد السید احمد عبد المنعم حسن النجار",
    "id": "252101108",
    "username": "sds-2026-6616",
    "password": "am306616",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد السید عبده ابراھیم",
    "id": "252100076",
    "username": "sds-2026-0374",
    "password": "am900374",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد السید محمد الترعى",
    "id": "252100077",
    "username": "sds-2026-0651",
    "password": "am200651",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد جاد السید عبدالنبى",
    "id": "252100078",
    "username": "sds-2026-1618",
    "password": "am301618",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد حسن محمد حسن",
    "id": "252100080",
    "username": "sds-2026-1017",
    "password": "am901017",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد ذكریا عبدالعال محمد",
    "id": "252100081",
    "username": "sds-2026-0638",
    "password": "am900638",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد عبد السید محمود والى",
    "id": "252100084",
    "username": "sds-2026-1494",
    "password": "am801494",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد عبدالسمیع ابراھیم السماحى",
    "id": "252100086",
    "username": "sds-2026-3676",
    "password": "am303676",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد عبدالعزیز على مصطفى ربیع",
    "id": "252100088",
    "username": "sds-2026-0893",
    "password": "am300893",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمد فرج متولى عویمر",
    "id": "252100089",
    "username": "sds-2026-4398",
    "password": "am904398",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمود احمد محمود علي",
    "id": "252100090",
    "username": "sds-2026-0593",
    "password": "am900593",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمود محمد تھامى ابراھیم",
    "id": "252100091",
    "username": "sds-2026-0856",
    "password": "am900856",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمود محمد عبد المجید",
    "id": "252101115",
    "username": "sds-2026-5199",
    "password": "am105199",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد محمود محمد محمد حسن",
    "id": "252100092",
    "username": "sds-2026-0592",
    "password": "am300592",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد ھانى عبدالحق حسن احمد",
    "id": "252100096",
    "username": "sds-2026-4476",
    "password": "ax304476",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد ھشام عاطف درویش العطوى",
    "id": "252100098",
    "username": "sds-2026-0176",
    "password": "ax300176",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد ھشام محمد غریب السید",
    "id": "252100099",
    "username": "sds-2026-4534",
    "password": "ax304534",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد وسیم احمد محمد ابو عرام",
    "id": "252100100",
    "username": "sds-2026-0119",
    "password": "aw300119",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "احمد ولید صبحى عزت حسن",
    "id": "252100102",
    "username": "sds-2026-2074",
    "password": "aw302074",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ادھم ابراھیم محمد منصور ابراھیم",
    "id": "252100107",
    "username": "sds-2026-1319",
    "password": "aa901319",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ادھم حسین السید محمد احمد الزغبى",
    "id": "252101124",
    "username": "sds-2026-1974",
    "password": "ah301974",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ادھم محمد ابراھیم السعید الشھابى",
    "id": "252100110",
    "username": "sds-2026-0515",
    "password": "am100515",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ادھم محمد احمد البدوى محمد سلیمان",
    "id": "252100111",
    "username": "sds-2026-0793",
    "password": "am300793",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اروى عمرو عبد الستار على عبد الله",
    "id": "252100115",
    "username": "sds-2026-0406",
    "password": "aa400406",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اروى محمد فتحى شحاتة مقبل",
    "id": "252100116",
    "username": "sds-2026-4164",
    "password": "am304164",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسامة محمد علي امام غنیم",
    "id": "252100119",
    "username": "sds-2026-0051",
    "password": "am910051",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسامة محمد فاروق محمد على",
    "id": "252100120",
    "username": "sds-2026-0275",
    "password": "am900275",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسامھ محمد اسامھ محمد فتحى عبدالحمید",
    "id": "252100123",
    "username": "sds-2026-9633",
    "password": "am319633",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسلام اشرف احمد مرسى احمد",
    "id": "252100127",
    "username": "sds-2026-0019",
    "password": "aa320019",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسلام السید محمد عبدالفتاح عرفھ",
    "id": "252100128",
    "username": "sds-2026-0931",
    "password": "aa300931",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسلام حاتم حامد حامد الدسوقى",
    "id": "252100131",
    "username": "sds-2026-0079",
    "password": "ah300079",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسلام عادل بحیرى منتصر منصور",
    "id": "252100133",
    "username": "sds-2026-6356",
    "password": "aa316356",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسلام عبدالعزیز محمد محمد عبدالكریم",
    "id": "252100134",
    "username": "sds-2026-7952",
    "password": "aa307952",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسلام محمد احمد ابراھیم الفقى",
    "id": "252100135",
    "username": "sds-2026-1014",
    "password": "am301014",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسلام ناجي محمد عبده الوصیف",
    "id": "252100137",
    "username": "sds-2026-3478",
    "password": "an203478",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسماء عزت محمد فریح محمد",
    "id": "252100140",
    "username": "sds-2026-7882",
    "password": "aa307882",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسماء محمد حسن اسماعیل سعاده",
    "id": "252100143",
    "username": "sds-2026-3269",
    "password": "am303269",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسماء محمد قطب السید محمد",
    "id": "252100145",
    "username": "sds-2026-6183",
    "password": "am306183",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسماعیل عبدالفتاح اسماعیل عبدالفتاح حسن",
    "id": "252100148",
    "username": "sds-2026-9016",
    "password": "aa309016",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اسماعیل محمد امام عبدالجلیل خلیفھ",
    "id": "252100150",
    "username": "sds-2026-2391",
    "password": "am302391",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اشرقت ولاء السید عیسى محمد",
    "id": "252100151",
    "username": "sds-2026-1849",
    "password": "aw301849",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اصالة حسام محمد السید نصر",
    "id": "252100152",
    "username": "sds-2026-0863",
    "password": "ah900863",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "اصالھ السید ابراھیم عبد الرحیم",
    "id": "252100153",
    "username": "sds-2026-2587",
    "password": "aa302587",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "افنان صلاح محمد ابراھیم العوضى",
    "id": "252100154",
    "username": "sds-2026-6502",
    "password": "as306502",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "افنان نیازى محمد عبد اللطیف سلیم",
    "id": "252100155",
    "username": "sds-2026-1965",
    "password": "an301965",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "الاء ابراھیم عبدالعزیز محمد عبدالله",
    "id": "252100157",
    "username": "sds-2026-8367",
    "password": "aa318367",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "الاء احمد عبدالعزیز محمد ابراھیم",
    "id": "252100158",
    "username": "sds-2026-0209",
    "password": "aa900209",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "الاء الشوادفى محمد حسن السید",
    "id": "252100160",
    "username": "sds-2026-0684",
    "password": "aa800684",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "الاء خالد عبدالعال مرسى احمد",
    "id": "252100162",
    "username": "sds-2026-4408",
    "password": "ak304408",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "الاء طارق محمد فراج احمد",
    "id": "252100164",
    "username": "sds-2026-0265",
    "password": "at400265",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "الاء عبدالحمید محمد محمد علوان",
    "id": "252100165",
    "username": "sds-2026-0406",
    "password": "aa900406",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "الاء محمد عبد السلام عبده مسعد",
    "id": "252100167",
    "username": "sds-2026-3028",
    "password": "am303028",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "الاء مھدى حامد مھدى محمد",
    "id": "252100168",
    "username": "sds-2026-2425",
    "password": "am902425",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "الحسین احمد محمد بشیر محمد",
    "id": "252100169",
    "username": "sds-2026-2877",
    "password": "aa312877",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "السعید محمد محمد عبدالمطلب سیداحمد",
    "id": "252100171",
    "username": "sds-2026-4218",
    "password": "am324218",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "السید حلمى الباز برھامى ابراھیم",
    "id": "252100172",
    "username": "sds-2026-2753",
    "password": "ah302753",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "السید محمد أمین على محمد الجزار",
    "id": "252100175",
    "username": "sds-2026-0333",
    "password": "am300333",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "السید مدحت احمد زاھر اسماعیل",
    "id": "252100176",
    "username": "sds-2026-3574",
    "password": "am303574",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "الشیماء محمد عبد الرحمن حسن رضوان",
    "id": "252100179",
    "username": "sds-2026-0588",
    "password": "am210588",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "امال نبیل على حسب الله محمد",
    "id": "252100181",
    "username": "sds-2026-5521",
    "password": "an305521",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "امل احمد مصطفى ابراھیم",
    "id": "252100183",
    "username": "sds-2026-1346",
    "password": "aa301346",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "امنیھ عطیھ عطا عطا على",
    "id": "252100186",
    "username": "sds-2026-4225",
    "password": "aa304225",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "امنیھ محمد السید على محمد ھنداوى",
    "id": "252100187",
    "username": "sds-2026-7302",
    "password": "am307302",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "امیره ابراھیم فتحي احمد على",
    "id": "252100189",
    "username": "sds-2026-3303",
    "password": "aa303303",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "امیره محمد محمد أمام السید",
    "id": "252100192",
    "username": "sds-2026-0043",
    "password": "am300043",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "امینھ محمد محمد زكى عبد المجید محجوب محمد",
    "id": "252100194",
    "username": "sds-2026-7067",
    "password": "am307067",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "انجى نعیم جورج شھدى",
    "id": "252100196",
    "username": "sds-2026-4007",
    "password": "an904007",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "انس احمد محمد محمد",
    "id": "252100198",
    "username": "sds-2026-0055",
    "password": "aa800055",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "انس غریب محمود محمود محمد سجاع",
    "id": "252100200",
    "username": "sds-2026-0096",
    "password": "ag300096",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایاد علي محمد محمد بغدادي",
    "id": "252100202",
    "username": "sds-2026-0435",
    "password": "aa900435",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایاد محمد امین محمد احمد",
    "id": "252100203",
    "username": "sds-2026-0897",
    "password": "am900897",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایثار احمد كمال محى الدین تمیم",
    "id": "252100206",
    "username": "sds-2026-0749",
    "password": "aa300749",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایثار عماد محمود عبدالفتاح امام",
    "id": "252100207",
    "username": "sds-2026-1749",
    "password": "aa301749",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایرینى انجیلوس بشرى قلاده نخنوخ",
    "id": "252100208",
    "username": "sds-2026-4541",
    "password": "aa304541",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایریني رأفت حفظ الله ملیكھ",
    "id": "252100209",
    "username": "sds-2026-3762",
    "password": "ar603762",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایمان السید محمد على نافع",
    "id": "252100211",
    "username": "sds-2026-1001",
    "password": "aa201001",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایمان بدوى احمد محمد احمد",
    "id": "252100212",
    "username": "sds-2026-1608",
    "password": "ab901608",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایمن محمد محمد انور احمد محمد محمد",
    "id": "252101145",
    "username": "sds-2026-3598",
    "password": "am303598",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایمى عماد زغلول شھدى اسطفانوس",
    "id": "252100217",
    "username": "sds-2026-0269",
    "password": "aa900269",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایمى فتحى فرج عبید",
    "id": "252100218",
    "username": "sds-2026-4187",
    "password": "af904187",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایھ احمد عبدالحمید على اسماعیل",
    "id": "252100219",
    "username": "sds-2026-6086",
    "password": "aa306086",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ایھ عید عبدالسلام عبدالرحمن اسماعیل",
    "id": "252100224",
    "username": "sds-2026-2725",
    "password": "aa302725",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بدر احمد سرى عزوز عبدالحفیظ",
    "id": "252100229",
    "username": "sds-2026-1415",
    "password": "ba301415",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "براءه ابراھیم محمد عبد الكریم ابراھیم",
    "id": "252100230",
    "username": "sds-2026-1044",
    "password": "ba801044",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بسام باز محمد احمد خضر",
    "id": "252100233",
    "username": "sds-2026-2935",
    "password": "bb312935",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بسملھ سعید عبدالعزیز عبید رضوان",
    "id": "252100236",
    "username": "sds-2026-2705",
    "password": "bs302705",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بسملھ محمد انور ابو السعود محمد على",
    "id": "252101102",
    "username": "sds-2026-0842",
    "password": "bm400842",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بسملھ محمد عبدالحمید عباس",
    "id": "252100240",
    "username": "sds-2026-0183",
    "password": "bm400183",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بسملھ محمد محمد احمد ابراھیم",
    "id": "252101144",
    "username": "sds-2026-1749",
    "password": "bm301749",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بسملھ محمود محمد عوض مصطفى شباره",
    "id": "252100242",
    "username": "sds-2026-2827",
    "password": "bm302827",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بسملھ ھاني محمد سعید فتحي امام",
    "id": "252100243",
    "username": "sds-2026-4504",
    "password": "bx304504",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بسمھ احمد حسن ابوالعنین مطر",
    "id": "252100245",
    "username": "sds-2026-0606",
    "password": "ba300606",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بسنت ابراھیم احمد ابراھیم ھاشم",
    "id": "252100247",
    "username": "sds-2026-3363",
    "password": "ba303363",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بسنت عبده شلبى حافظ ریان",
    "id": "252100248",
    "username": "sds-2026-1364",
    "password": "ba901364",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بسنت كرم عبدالله محمد الھادى حسین",
    "id": "252100249",
    "username": "sds-2026-1881",
    "password": "bk301881",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بلال السید رشاد حسن حسنین",
    "id": "252100251",
    "username": "sds-2026-4991",
    "password": "ba304991",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بیتر ھانى صبحى جرجس نیروز",
    "id": "252100252",
    "username": "sds-2026-0317",
    "password": "bx900317",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بیشوى رمزى فاروق نصیف حبش",
    "id": "252100253",
    "username": "sds-2026-0599",
    "password": "br300599",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "بیشوي یاسر فھمي شفیق حكیم",
    "id": "252100254",
    "username": "sds-2026-0096",
    "password": "bx300096",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "تسنیم سامح محمد علي محمود",
    "id": "252100255",
    "username": "sds-2026-2587",
    "password": "ts312587",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "تقى احمد الرفاعى محمد الدسوقى",
    "id": "252100256",
    "username": "sds-2026-0066",
    "password": "ta200066",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "تقى ناصر محمد عطیھ محمد",
    "id": "252100257",
    "username": "sds-2026-0565",
    "password": "tn320565",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "جلال مؤمن احمد محى الدین محمد فھیم ابراھیم",
    "id": "252100260",
    "username": "sds-2026-0736",
    "password": "jm300736",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "جنھ اسماعیل محمود اسماعیل عبدالله",
    "id": "252100263",
    "username": "sds-2026-0188",
    "password": "ja900188",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "جنى احمد أحمد البدوى الحربى",
    "id": "252100266",
    "username": "sds-2026-0109",
    "password": "ja300109",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "جنى عبدالناصر عبدالنبى احمد عبدالعال",
    "id": "252100270",
    "username": "sds-2026-0206",
    "password": "ja900206",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "جنى محمد ابراھیم عبد الرحمن الشویخ",
    "id": "252100271",
    "username": "sds-2026-0566",
    "password": "jm300566",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "جنى محمد طلعت عبده سلیمان",
    "id": "252101189",
    "username": "sds-2026-1062",
    "password": "jm901062",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "جنى مصطفى انسى مصطفى العدنى",
    "id": "252101168",
    "username": "sds-2026-0227",
    "password": "jm300227",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "جودي عمرو محمود محمود ابوزید رخا",
    "id": "252100279",
    "username": "sds-2026-0061",
    "password": "ja300061",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "جورج عماد سعد جاب الله",
    "id": "252100280",
    "username": "sds-2026-1636",
    "password": "ja601636",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "جوزیف اسحق سامى اسحق یونان",
    "id": "252101160",
    "username": "sds-2026-0991",
    "password": "ja300991",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حبیبة احمد ابراھیم على",
    "id": "252100288",
    "username": "sds-2026-0289",
    "password": "ha900289",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حبیبة محمود السید محمود عبدالرحمن",
    "id": "252100290",
    "username": "sds-2026-0444",
    "password": "hm900444",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حبیبة ھانى ابراھیم محمد",
    "id": "252101161",
    "username": "sds-2026-4245",
    "password": "hx304245",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حبیبھ اشرف سلامھ سلیمان سلمان",
    "id": "252100291",
    "username": "sds-2026-0709",
    "password": "ha900709",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حبیبھ سعید محمد احمد عبد القادر",
    "id": "252101114",
    "username": "sds-2026-0502",
    "password": "hs300502",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حسام محمد السید ابوھاشم",
    "id": "252100300",
    "username": "sds-2026-5955",
    "password": "hm315955",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حسام محمد السید احمد ابراھیم",
    "id": "252100301",
    "username": "sds-2026-1195",
    "password": "hm301195",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حسن السید محمد محمد عید",
    "id": "252100302",
    "username": "sds-2026-2815",
    "password": "ha202815",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حسن عبدالرحیم منصور سلیمان حماد",
    "id": "252100303",
    "username": "sds-2026-2417",
    "password": "ha302417",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حسین غریب حسین محمود احمد",
    "id": "252100307",
    "username": "sds-2026-0193",
    "password": "hg900193",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حسین محمد محمد مصطفى",
    "id": "252101097",
    "username": "sds-2026-0797",
    "password": "hm900797",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حلا عبده احمد عبد الله أحمد",
    "id": "252100309",
    "username": "sds-2026-0084",
    "password": "ha300084",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حمدى محمد محمد الغریب مندور",
    "id": "252100312",
    "username": "sds-2026-0934",
    "password": "hm100934",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حنین ابراھیم السید طھ خلیل اسماعیل",
    "id": "252100314",
    "username": "sds-2026-0048",
    "password": "ha300048",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حنین حسن محمد الصادق محمد",
    "id": "252100317",
    "username": "sds-2026-5821",
    "password": "hh305821",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حنین نبیل محمد مضیھا منصور",
    "id": "252100321",
    "username": "sds-2026-1506",
    "password": "hn101506",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "حورالعین عبدالمنعم عبدالسلام عبدالمنعم خلف",
    "id": "252100326",
    "username": "sds-2026-0763",
    "password": "ha300763",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "خالد ابراھیم امین عبدالحمید محمد",
    "id": "252100327",
    "username": "sds-2026-3136",
    "password": "ka903136",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "خالد عصام الدین رجب احمد حافظ",
    "id": "252100329",
    "username": "sds-2026-0059",
    "password": "ka500059",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "خالد محمد جلال محمد طلبھ",
    "id": "252100331",
    "username": "sds-2026-4531",
    "password": "km314531",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "خالد محمد جمعھ محمد المحجوب",
    "id": "252100332",
    "username": "sds-2026-1436",
    "password": "km101436",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "خالد محمد مختار اسماعیل محمد",
    "id": "252100334",
    "username": "sds-2026-2818",
    "password": "km302818",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "خالد ممدوح بیومي احمد رمضان",
    "id": "252100335",
    "username": "sds-2026-0911",
    "password": "km900911",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "دعاء فاروق مصطفى محمد ادریس",
    "id": "252100341",
    "username": "sds-2026-1943",
    "password": "df301943",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "دعاء منصور احمد الصادق اسماعیل",
    "id": "252100343",
    "username": "sds-2026-4983",
    "password": "dm304983",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "دنیا عبدالله عبدالسلام عبدالله محمد",
    "id": "252100345",
    "username": "sds-2026-3043",
    "password": "da303043",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "دنیا محمد سمیر محمد مرسى",
    "id": "252100346",
    "username": "sds-2026-1407",
    "password": "dm301407",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "دینا محمد جامع مقبل نصار",
    "id": "252100347",
    "username": "sds-2026-0862",
    "password": "dm900862",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رأفت علاء رأفت السعید عبد المجید",
    "id": "252100349",
    "username": "sds-2026-3611",
    "password": "ra253611",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رائد صلاح شعیب ابراھیم ابراھیم عوف",
    "id": "252100351",
    "username": "sds-2026-5037",
    "password": "rs205037",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رامز ایاد محمود احمد محمد النبریصى",
    "id": "252100352",
    "username": "sds-2026-0213",
    "password": "ra200213",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رامى مصطفى محمد عثمان مصطفي العوضى",
    "id": "252100353",
    "username": "sds-2026-1276",
    "password": "rm301276",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رانیا اشرف عبدالرحمن محمد الدندیطى",
    "id": "252100354",
    "username": "sds-2026-9562",
    "password": "ra349562",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رباب عبدالله عبدالكریم فاید موسى",
    "id": "252100355",
    "username": "sds-2026-4464",
    "password": "ra304464",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رحاب احمد ابراھیم محمد محمد",
    "id": "252101133",
    "username": "sds-2026-1743",
    "password": "ra301743",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رحاب اسماعیل محمد السید حسن",
    "id": "252100358",
    "username": "sds-2026-0502",
    "password": "ra900502",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رحمھ السید المرسى على العاصى",
    "id": "252100362",
    "username": "sds-2026-2186",
    "password": "ra202186",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رحمھ سمیر السادات الوردانى محمود",
    "id": "252100364",
    "username": "sds-2026-2026",
    "password": "rs202026",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رشا محمد ابراھیم الدسوقى دیدامونى احمد",
    "id": "252100368",
    "username": "sds-2026-5525",
    "password": "rm305525",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رضا عبده محمد حامد محمد",
    "id": "252100370",
    "username": "sds-2026-0632",
    "password": "ra300632",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رضوى یوسف احمد یوسف احمد",
    "id": "252100372",
    "username": "sds-2026-0928",
    "password": "rx300928",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رغده محمد طنطاوى عبدالمعطى طنطاوى",
    "id": "252100374",
    "username": "sds-2026-0622",
    "password": "rm300622",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رفیده سعد احمد مسلم عیسوى",
    "id": "252100375",
    "username": "sds-2026-1547",
    "password": "rs301547",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رقیھ سعد محمد عیسى جاد الكریم",
    "id": "252100376",
    "username": "sds-2026-0302",
    "password": "rs910302",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رنا ابراھیم محمد ابراھیم حسین",
    "id": "252100377",
    "username": "sds-2026-0444",
    "password": "ra200444",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رنا ماھر عبد الرحمن محمد الصعیدى",
    "id": "252100379",
    "username": "sds-2026-0205",
    "password": "rm100205",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رنا ھشام محمد مصطفى ھندام",
    "id": "252100380",
    "username": "sds-2026-1348",
    "password": "rx201348",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "رواء فتحى محمد الدسوقى ابراھیم",
    "id": "252100382",
    "username": "sds-2026-2784",
    "password": "rf202784",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "روان ابراھیم عبد المقصود محمد سلیم",
    "id": "252100384",
    "username": "sds-2026-4582",
    "password": "ra304582",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "روان احمد ابوالنصر حفنى",
    "id": "252100385",
    "username": "sds-2026-0524",
    "password": "ra900524",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "روان رضا سعید على محمد",
    "id": "252100388",
    "username": "sds-2026-1543",
    "password": "rr901543",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "روان طارق محمد حسن مرسى",
    "id": "252100389",
    "username": "sds-2026-7063",
    "password": "rt307063",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "روان عادل محمد السید احمد مدالله",
    "id": "252100390",
    "username": "sds-2026-1366",
    "password": "ra301366",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "روان محمد شكرى صالح ابرھیم",
    "id": "252100395",
    "username": "sds-2026-1927",
    "password": "rm301927",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "روضھ فوزي عباس فوزى محمد",
    "id": "252100397",
    "username": "sds-2026-0622",
    "password": "rf900622",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "روفینا ایمن لبیب غبیوس",
    "id": "252100400",
    "username": "sds-2026-0266",
    "password": "ra900266",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ریاض السید محمد عبد اللطیف ابو یوسف",
    "id": "252100405",
    "username": "sds-2026-0179",
    "password": "ra300179",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ریم ابراھیم محمد محمد",
    "id": "252100407",
    "username": "sds-2026-3589",
    "password": "ra303589",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ریم عبدالباسط عبدالرحمن خلیل حسن",
    "id": "252100408",
    "username": "sds-2026-1361",
    "password": "ra301361",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ریھام حجازى یوسف یوسف العدوى",
    "id": "252100414",
    "username": "sds-2026-1628",
    "password": "rh101628",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ریھام محمد محمد محمد",
    "id": "252100415",
    "username": "sds-2026-1703",
    "password": "rm601703",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "زیاد صدیق اسماعیل احمد فرغلى",
    "id": "252101110",
    "username": "sds-2026-0475",
    "password": "zs900475",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "زیاد طارق حسین مصطفى محمد",
    "id": "252100418",
    "username": "sds-2026-1836",
    "password": "zt401836",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "زیاد محمد زغلول ھندام",
    "id": "252100421",
    "username": "sds-2026-3491",
    "password": "zm203491",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "زیاد محمد محمود عبداللاه راوى",
    "id": "252100423",
    "username": "sds-2026-7196",
    "password": "zm907196",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "زیاد ھاني محمد السید الغنام",
    "id": "252100424",
    "username": "sds-2026-0257",
    "password": "zx300257",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سارة جلال ابو ضیف عبدالحافض",
    "id": "252100426",
    "username": "sds-2026-0362",
    "password": "sj900362",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ساره السید عبد الباسط السید مصطفى ھلال",
    "id": "252100427",
    "username": "sds-2026-2461",
    "password": "sa212461",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ساره رجب عبدالعزیز ابراھیم محمد",
    "id": "252100428",
    "username": "sds-2026-5261",
    "password": "sr305261",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ساره عبد الله عوض أحمد محمد",
    "id": "252100432",
    "username": "sds-2026-2405",
    "password": "sa302405",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ساره محمد عبدالله ادریس محمود عبدالراضى",
    "id": "252100435",
    "username": "sds-2026-2369",
    "password": "sm102369",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ساره محمد عبدالله محمد عطیھ",
    "id": "252100436",
    "username": "sds-2026-0049",
    "password": "sm800049",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سامى سعید صالح سالم یوسف",
    "id": "252100439",
    "username": "sds-2026-1059",
    "password": "ss321059",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سلمھ محمد السید محمود محمد",
    "id": "252100447",
    "username": "sds-2026-1687",
    "password": "sm901687",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سلمى جمال حمدى صالح",
    "id": "252100449",
    "username": "sds-2026-4665",
    "password": "sj404665",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سلمى محمد السید ابراھیم عبد الحافظ",
    "id": "252100454",
    "username": "sds-2026-0362",
    "password": "sm300362",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سلیمان محمد سلیمان جعفر البلقھ",
    "id": "252101099",
    "username": "sds-2026-2538",
    "password": "sm302538",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سما عبده احمد صدیق على",
    "id": "252100459",
    "username": "sds-2026-0389",
    "password": "sa900389",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سماح السید ربیع محمد الدسوقى",
    "id": "252100464",
    "username": "sds-2026-1944",
    "password": "sa301944",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سندس احمد عطیة عبدالعزیز عطیھ",
    "id": "252100466",
    "username": "sds-2026-0045",
    "password": "sa900045",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سندس عماد حامد ابراھیم حسین",
    "id": "252100467",
    "username": "sds-2026-0501",
    "password": "sa900501",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سھیلھ محمد سعید رجب ناصف",
    "id": "252100470",
    "username": "sds-2026-2941",
    "password": "sm302941",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سوزان حمدى ابراھیم محمد عبد القادر",
    "id": "252100471",
    "username": "sds-2026-8006",
    "password": "sh308006",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "سیف الدین ھاني ابراھیم الدسوقي محمود علي",
    "id": "252100472",
    "username": "sds-2026-0293",
    "password": "sa300293",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شادى احمد محمد ابو الفتوح",
    "id": "252101104",
    "username": "sds-2026-7055",
    "password": "sa307055",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شذى عماد حسن على خلیل",
    "id": "252100475",
    "username": "sds-2026-4966",
    "password": "sa304966",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شروق ماھر على صالح على",
    "id": "252100476",
    "username": "sds-2026-3282",
    "password": "sm303282",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شروق محمود صادق عیسى ابو زید",
    "id": "252100477",
    "username": "sds-2026-3704",
    "password": "sm303704",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شریف علاء محمد محمود عبید راشد",
    "id": "252100478",
    "username": "sds-2026-0253",
    "password": "sa300253",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شمس رضا مختار حسین",
    "id": "252100479",
    "username": "sds-2026-0562",
    "password": "sr400562",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شمس محمد یونس عبدالعاطى سلیمان",
    "id": "252100480",
    "username": "sds-2026-2168",
    "password": "sm302168",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شھاب متولى السید محمد ابراھیم",
    "id": "252100481",
    "username": "sds-2026-0897",
    "password": "sm800897",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شھد احمد سعید حمدى الزملوط",
    "id": "252100482",
    "username": "sds-2026-0328",
    "password": "sa900328",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شھد حسن جاد عبد المنعم عبد القادر",
    "id": "252100485",
    "username": "sds-2026-7225",
    "password": "sh307225",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شھد سامى عبد السمیع عطوه محمد",
    "id": "252100486",
    "username": "sds-2026-0321",
    "password": "ss300321",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شھد شریف السید محمد كامل",
    "id": "252100487",
    "username": "sds-2026-0362",
    "password": "ss300362",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شھد عبداللطیف ابراھیم عبداللطیف ماضى",
    "id": "252100489",
    "username": "sds-2026-1864",
    "password": "sa321864",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شھد عمرو محمد عبد الرحیم على",
    "id": "252101127",
    "username": "sds-2026-0167",
    "password": "sa900167",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شھد كامل عبدالمنعم على موسى",
    "id": "252100491",
    "username": "sds-2026-5327",
    "password": "sk305327",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شھد محمد عبدالحمید احمد علي رزق",
    "id": "252100493",
    "username": "sds-2026-2127",
    "password": "sm302127",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شھیره ایھاب عبد الغفار محمد على",
    "id": "252100495",
    "username": "sds-2026-1127",
    "password": "sa201127",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "شیماء عبد الخالق عبدالله سلیمان",
    "id": "252101188",
    "username": "sds-2026-0568",
    "password": "sa900568",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "صالح محسن صالح عبد العال محمد",
    "id": "252100499",
    "username": "sds-2026-2897",
    "password": "sm302897",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "صلاح عبده صلاح محمد اسماعیل",
    "id": "252101186",
    "username": "sds-2026-0554",
    "password": "sa900554",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عائشھ محمد ابراھیم ابراھیم محمد حماده",
    "id": "252100504",
    "username": "sds-2026-0347",
    "password": "am300347",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عادل رایق صدقى مسعود سعد",
    "id": "252101101",
    "username": "sds-2026-1579",
    "password": "ar301579",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عاصم عمر عبدالنعیم عمر یونس",
    "id": "252100506",
    "username": "sds-2026-0659",
    "password": "aa900659",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبد الرحمن احمد محمد موسى عطاالله عایش",
    "id": "252100520",
    "username": "sds-2026-5019",
    "password": "aa305019",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبد الرحمن اسماعیل خلف الله السید احمد",
    "id": "252100521",
    "username": "sds-2026-0573",
    "password": "aa900573",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبد الرحمن اشرف عبدالله السید الجداوى",
    "id": "252100522",
    "username": "sds-2026-1758",
    "password": "aa301758",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبد الرحمن السید احمد محمد عطیھ",
    "id": "252100523",
    "username": "sds-2026-0312",
    "password": "aa900312",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبد الرحمن طارق سمیر عبد العزیز عبد الھادى",
    "id": "252100513",
    "username": "sds-2026-0098",
    "password": "aa600098",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبد الرحمن عبدالله عبدالرحمن محمد متولى",
    "id": "252100528",
    "username": "sds-2026-0095",
    "password": "aa900095",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبد الرحمن محمد السید ابراھیم عبدالله",
    "id": "252100529",
    "username": "sds-2026-7574",
    "password": "aa307574",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبد الرحمن محمد سالم كریم سالم",
    "id": "252100530",
    "username": "sds-2026-4877",
    "password": "aa904877",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبد الرحمن محمد صالح عبدالرحمن عبدالسلام",
    "id": "252100532",
    "username": "sds-2026-6058",
    "password": "aa306058",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبد الرحمن محمد یوسف احمد محمد",
    "id": "252100534",
    "username": "sds-2026-3093",
    "password": "aa913093",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبد الرحمن محمود علي محمود سویلم",
    "id": "252100535",
    "username": "sds-2026-0097",
    "password": "aa300097",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبدالسمیع ولید عبدالسمیع ابراھیم محمد",
    "id": "252100536",
    "username": "sds-2026-1392",
    "password": "aw311392",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبدالقادر یوسف عبدالقادر عبدالله ابراھیم",
    "id": "252100539",
    "username": "sds-2026-3873",
    "password": "ax303873",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبداللطیف محمد عبداللطیف ابراھیم الغریب",
    "id": "252100540",
    "username": "sds-2026-0397",
    "password": "am310397",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبدالله السید سویلم سلیمان على",
    "id": "252100542",
    "username": "sds-2026-2211",
    "password": "aa302211",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبدالله عبدالعزیز عبدالله ابراھیم محمد",
    "id": "252100544",
    "username": "sds-2026-0432",
    "password": "aa900432",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبدالله عبدالناصر ابراھیم حراره",
    "id": "252100545",
    "username": "sds-2026-2934",
    "password": "aa102934",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبدالله محمد ابو الحمد حافظ محمود",
    "id": "252100546",
    "username": "sds-2026-0278",
    "password": "am900278",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبدالله محمد احسان احسان محمود",
    "id": "252100547",
    "username": "sds-2026-0292",
    "password": "am300292",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبدالوھاب محمد عبدالوھاب احمد یوسف",
    "id": "252100549",
    "username": "sds-2026-1419",
    "password": "am901419",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عبده محمد عبدالفتاح محمد محمد",
    "id": "252100550",
    "username": "sds-2026-1336",
    "password": "am301336",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عطا سمیر عطا مترى حنین",
    "id": "252100555",
    "username": "sds-2026-0357",
    "password": "as900357",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "علا عبد الناصر محمود مرسى محمد",
    "id": "252100557",
    "username": "sds-2026-3704",
    "password": "aa303704",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "علاء جمال محمود السید خضیر",
    "id": "252100559",
    "username": "sds-2026-0538",
    "password": "aj300538",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "علاء حمدى فاروق زكى رخا",
    "id": "252100560",
    "username": "sds-2026-3393",
    "password": "ah603393",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "علاء عصام علي السید سلامھ",
    "id": "252100561",
    "username": "sds-2026-5171",
    "password": "aa305171",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "على احمد على عوض المتیم",
    "id": "252100562",
    "username": "sds-2026-3254",
    "password": "aa303254",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "على اسامھ على السید على",
    "id": "252100565",
    "username": "sds-2026-1595",
    "password": "aa901595",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "على خالد على محمد عبدربھ",
    "id": "252100567",
    "username": "sds-2026-2319",
    "password": "ak352319",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "علیاء زكریا سید حسن",
    "id": "252100571",
    "username": "sds-2026-0243",
    "password": "az400243",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر ابراھیم محمد علي محمد",
    "id": "252100574",
    "username": "sds-2026-0059",
    "password": "aa300059",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر احمد اسماعیل احمد اسماعیل",
    "id": "252100575",
    "username": "sds-2026-0234",
    "password": "aa300234",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر احمد محمد غندور",
    "id": "252101119",
    "username": "sds-2026-0216",
    "password": "aa900216",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر احمد محمد محمد ادریس",
    "id": "252100576",
    "username": "sds-2026-2018",
    "password": "aa302018",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر خالد احمد حامد محمد",
    "id": "252100581",
    "username": "sds-2026-1615",
    "password": "ak301615",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر خالد عمر سید عبد الرحمن",
    "id": "252101136",
    "username": "sds-2026-0334",
    "password": "ak400334",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر خضرى محمد نور",
    "id": "252100582",
    "username": "sds-2026-0114",
    "password": "ak100114",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر عبداللطیف جاب الله محمد عطیھ",
    "id": "252100587",
    "username": "sds-2026-2653",
    "password": "aa302653",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر على احمد على محمد",
    "id": "252100588",
    "username": "sds-2026-3153",
    "password": "aa303153",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر عید عبدالعزیز عبداللطیف",
    "id": "252100589",
    "username": "sds-2026-1254",
    "password": "aa901254",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر فخرى فكرى احمد عیاد",
    "id": "252100590",
    "username": "sds-2026-3619",
    "password": "af303619",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر مجدى فؤاد عبده محمد",
    "id": "252100591",
    "username": "sds-2026-1018",
    "password": "am301018",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر محمد حمدى محمد سلیم",
    "id": "252100596",
    "username": "sds-2026-1114",
    "password": "am301114",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر محمد صادق مسعد النمل",
    "id": "252100598",
    "username": "sds-2026-0531",
    "password": "am210531",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر محمد عبدالحمید عبداللطیف سالم",
    "id": "252100599",
    "username": "sds-2026-1338",
    "password": "am301338",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر مختار محمد مختار عبد الحلیم",
    "id": "252100601",
    "username": "sds-2026-3254",
    "password": "am203254",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمر مرسى عبدالرحیم مرسى حسن",
    "id": "252100602",
    "username": "sds-2026-3257",
    "password": "am303257",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمرو ایمن السید محمد على الشوربجى",
    "id": "252100604",
    "username": "sds-2026-1657",
    "password": "aa201657",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "عمرو ضیاء الدین عمر احمد السید",
    "id": "252100605",
    "username": "sds-2026-2895",
    "password": "ad302895",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فادى احمد محمد فتحى محمد",
    "id": "252100609",
    "username": "sds-2026-3156",
    "password": "fa303156",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فادى علاء الدین مصطفى حسین عبدالله",
    "id": "252100610",
    "username": "sds-2026-0356",
    "password": "fa900356",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فارس احمد السید احمد ابو السعود",
    "id": "252100612",
    "username": "sds-2026-6217",
    "password": "fa306217",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فارس السید محمود مصطفى محمود",
    "id": "252100613",
    "username": "sds-2026-2873",
    "password": "fa352873",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فارس شحتة عبد الفتاح عبد الرحمن",
    "id": "252101162",
    "username": "sds-2026-8492",
    "password": "fs308492",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فارس عبد الحمید محمود عبد الحمید ادریس",
    "id": "252101163",
    "username": "sds-2026-2278",
    "password": "fa302278",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فارس محمد صلاح السید محمد",
    "id": "252100616",
    "username": "sds-2026-2672",
    "password": "fm302672",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فارس محمد على محمدعلى العایدى",
    "id": "252100617",
    "username": "sds-2026-3859",
    "password": "fm303859",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فاطمة الزھراء عبدالرحمن احمد محمد رواج",
    "id": "252100622",
    "username": "sds-2026-2865",
    "password": "fa302865",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فاطمة الزھراء محمود محمد عبد النعیم مھران",
    "id": "252101143",
    "username": "sds-2026-3542",
    "password": "fa303542",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فاطمة عبد الحمید حسن ابراھیم",
    "id": "252101177",
    "username": "sds-2026-1181",
    "password": "fa901181",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فاطمھ احمد عبدالرحیم عمر سرحان",
    "id": "252100626",
    "username": "sds-2026-1702",
    "password": "fa301702",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فایزه عماد صلاح محمدالسید القطاوى",
    "id": "252100628",
    "username": "sds-2026-0982",
    "password": "fa800982",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فتحى عبدالحلیم فتحى عبدالعال السید",
    "id": "252100629",
    "username": "sds-2026-3215",
    "password": "fa303215",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فرح إبراھیم سعد سرور محمد",
    "id": "252100630",
    "username": "sds-2026-6765",
    "password": "fa306765",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فرح ابراھیم جمال ابراھیم محمد شعلان",
    "id": "252100631",
    "username": "sds-2026-6284",
    "password": "fa306284",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فرح عصام السید راغب السید",
    "id": "252100633",
    "username": "sds-2026-0748",
    "password": "fa300748",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فرح محمد حسن محمد خلیل",
    "id": "252100635",
    "username": "sds-2026-0288",
    "password": "fm400288",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فرح محمد طھ اسماعیل علي القاضي",
    "id": "252100637",
    "username": "sds-2026-2066",
    "password": "fm302066",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فرحھ محمد حسن محمد عبدالله",
    "id": "252100639",
    "username": "sds-2026-1684",
    "password": "fm311684",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فیرونیكا شارلي ماھر جرجس",
    "id": "252100642",
    "username": "sds-2026-0224",
    "password": "fs300224",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فیصل محمد جمعھ سلیمان ابومسامح",
    "id": "252100645",
    "username": "sds-2026-3872",
    "password": "fm403872",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "فیفى حسن جابر على على",
    "id": "252100646",
    "username": "sds-2026-2028",
    "password": "fh302028",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كارین ریمون نسیم ملیكھ غبریال",
    "id": "252100647",
    "username": "sds-2026-0264",
    "password": "kr300264",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كریم احمد لبیب محمد عزب",
    "id": "252100649",
    "username": "sds-2026-0835",
    "password": "ka700835",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كریم احمد محمد محمد سلیم",
    "id": "252101142",
    "username": "sds-2026-2118",
    "password": "ka302118",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كریم المھدى سالم محمد سالم",
    "id": "252100650",
    "username": "sds-2026-4513",
    "password": "ka204513",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كریم سعید على عباس محمد",
    "id": "252100654",
    "username": "sds-2026-2838",
    "password": "ks302838",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كریم عبدالله محمد سلامھ",
    "id": "252101141",
    "username": "sds-2026-0277",
    "password": "ka300277",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كریم فوزى احمد صادومھ",
    "id": "252101135",
    "username": "sds-2026-1072",
    "password": "kf801072",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كریم منصور محمد ابراھیم محمد",
    "id": "252101140",
    "username": "sds-2026-4351",
    "password": "km314351",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كریم یاسر عوض حسین على",
    "id": "252100657",
    "username": "sds-2026-0212",
    "password": "kx300212",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كنزى ابراھیم احمد ابو زید السید",
    "id": "252100659",
    "username": "sds-2026-0165",
    "password": "ka900165",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كنزى احمد محمد عبده محمد بكیر",
    "id": "252100660",
    "username": "sds-2026-0121",
    "password": "ka300121",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كنزي حازم حمدین عبدالقادر",
    "id": "252100661",
    "username": "sds-2026-0082",
    "password": "kh900082",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "كنزي مصطفى محمد حسن ابوالعنین",
    "id": "252100662",
    "username": "sds-2026-0226",
    "password": "km900226",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "لامیس سامح عبدالمعطى السید",
    "id": "252100663",
    "username": "sds-2026-1563",
    "password": "ls301563",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ماجده محمد ابراھیم جمعھ الشافعي",
    "id": "252100670",
    "username": "sds-2026-5168",
    "password": "mm305168",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مارفین نجیب نبیل نجیب یونان",
    "id": "252100673",
    "username": "sds-2026-3704",
    "password": "mn203704",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مارفینا عاطف فریز موسى بخیت",
    "id": "252100674",
    "username": "sds-2026-0722",
    "password": "ma900722",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مارك مجدى جرجس ھندى صلیب",
    "id": "252100676",
    "username": "sds-2026-1211",
    "password": "mm301211",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مازن ایمن وادى النیل مسعد حجازى",
    "id": "252100680",
    "username": "sds-2026-0454",
    "password": "ma300454",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مازن عبدالستار محمد غنیمى السید",
    "id": "252100683",
    "username": "sds-2026-8336",
    "password": "ma318336",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مازن محمود صابر عبدالعزیز عبدالجلیل",
    "id": "252100685",
    "username": "sds-2026-2593",
    "password": "mm902593",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مالك محمود حسن السید الدمیاطى",
    "id": "252100687",
    "username": "sds-2026-0354",
    "password": "mm300354",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مالك ولید محمد عبد الحى ابو حرب",
    "id": "252100688",
    "username": "sds-2026-4212",
    "password": "mw304212",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مایا صلاح مدكور عبدالغنى محمد",
    "id": "252101063",
    "username": "sds-2026-0305",
    "password": "ms900305",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محسن سلیمان فھمى حسن تویج",
    "id": "252100689",
    "username": "sds-2026-0358",
    "password": "ms300358",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد احمد السید عبدالحمید مصطفى",
    "id": "252100695",
    "username": "sds-2026-5991",
    "password": "ma305991",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد احمد صلاح علي حسین",
    "id": "252100696",
    "username": "sds-2026-0692",
    "password": "ma310692",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد احمد عبدالسلام سالم",
    "id": "252100698",
    "username": "sds-2026-3692",
    "password": "ma303692",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد احمد عبدالعظیم السید شبانھ",
    "id": "252100699",
    "username": "sds-2026-5432",
    "password": "ma305432",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد احمد محمد القاسمى قاسم",
    "id": "252100702",
    "username": "sds-2026-1138",
    "password": "ma301138",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد احمد محمد محمد إبراھیم",
    "id": "252100705",
    "username": "sds-2026-3234",
    "password": "ma303234",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد احمد منصور ابراھیم غازى",
    "id": "252100706",
    "username": "sds-2026-0615",
    "password": "ma300615",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد اسماعیل ابو الحمد احمد حمید",
    "id": "252100707",
    "username": "sds-2026-1071",
    "password": "ma901071",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد اسماعیل سعد الدین اسماعیل",
    "id": "252100708",
    "username": "sds-2026-0294",
    "password": "ma400294",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد اشرف احمد محمد",
    "id": "252100709",
    "username": "sds-2026-3355",
    "password": "ma303355",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد اشرف عبدالله احمد محمد",
    "id": "252101139",
    "username": "sds-2026-2858",
    "password": "ma302858",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد اشرف قطب محمد خلیل",
    "id": "252100710",
    "username": "sds-2026-1597",
    "password": "ma911597",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد السعید عبدالمحسن عبدالرازق عشمھ",
    "id": "252100711",
    "username": "sds-2026-0514",
    "password": "ma200514",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد السید سالم حسن السید",
    "id": "252100715",
    "username": "sds-2026-1578",
    "password": "ma301578",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد السید عبدالعاطى فرج السید",
    "id": "252100719",
    "username": "sds-2026-6416",
    "password": "ma306416",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد السید عبدالقادر محمد عبدالقادر",
    "id": "252100720",
    "username": "sds-2026-6098",
    "password": "ma306098",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد السید فتحى سالم",
    "id": "252101164",
    "username": "sds-2026-2258",
    "password": "ma302258",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد السید محمد محمد العجمى",
    "id": "252100724",
    "username": "sds-2026-6952",
    "password": "ma306952",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد جلال السید محمد سلیمان",
    "id": "252100727",
    "username": "sds-2026-4237",
    "password": "mj304237",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد حامد محمد صلاح الدین حمزة مصطفى",
    "id": "252100728",
    "username": "sds-2026-8252",
    "password": "mh318252",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد حسن عبد الفتاح أحمد عطیھ",
    "id": "252100729",
    "username": "sds-2026-3231",
    "password": "mh303231",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد حسین محمد محمد محمود",
    "id": "252100730",
    "username": "sds-2026-1036",
    "password": "mh101036",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد سالم عبده ابو طالب احمد",
    "id": "252100734",
    "username": "sds-2026-1218",
    "password": "ms801218",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد سامى عبدالفتاح محمد محمد",
    "id": "252100736",
    "username": "sds-2026-7997",
    "password": "ms307997",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد صلاح محمد حسین طھ مرسي",
    "id": "252100739",
    "username": "sds-2026-0476",
    "password": "ms900476",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد طارق ابراھیم ابو النیل مرسى",
    "id": "252101151",
    "username": "sds-2026-8638",
    "password": "mt308638",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد طارق محمد غریب احمد",
    "id": "252101126",
    "username": "sds-2026-2279",
    "password": "mt302279",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد طھ عبدالجلیل على احمد السید",
    "id": "252100744",
    "username": "sds-2026-3077",
    "password": "mt303077",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد عادل رمضان احمد ابو طوالھ",
    "id": "252100745",
    "username": "sds-2026-0255",
    "password": "ma310255",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد عبد السلام احمد محمود عوض",
    "id": "252101165",
    "username": "sds-2026-2773",
    "password": "ma302773",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد عبدالرحمن عبدالحمید محمد محمد عماره",
    "id": "252100750",
    "username": "sds-2026-2756",
    "password": "ma302756",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد عبده محمد محمد على",
    "id": "252100755",
    "username": "sds-2026-8198",
    "password": "ma308198",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد عزت عبدالبدیع محمد حسن",
    "id": "252100756",
    "username": "sds-2026-4113",
    "password": "ma304113",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد عمر عبدالمعطي محمد محمد",
    "id": "252100761",
    "username": "sds-2026-0253",
    "password": "ma900253",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد عمرو عبداللطیف محمد عبد ربھ",
    "id": "252100762",
    "username": "sds-2026-1492",
    "password": "ma901492",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد عوض عبده محمدعبد الرازق",
    "id": "252100763",
    "username": "sds-2026-0096",
    "password": "ma200096",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد كمال محمد غریب محمد",
    "id": "252100767",
    "username": "sds-2026-0917",
    "password": "mk300917",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد ماھر مسلم محمد سلیمان",
    "id": "252101098",
    "username": "sds-2026-2878",
    "password": "mm302878",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد محمد احمد عبدالرازق محمد",
    "id": "252100769",
    "username": "sds-2026-0919",
    "password": "mm200919",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد محمد السید محمد عبد الحلیم عسكر",
    "id": "252100770",
    "username": "sds-2026-3311",
    "password": "mm303311",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد محمد حنیدق السید النمس",
    "id": "252100771",
    "username": "sds-2026-0314",
    "password": "mm900314",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد محمد محمد احمد دویب",
    "id": "252100772",
    "username": "sds-2026-0777",
    "password": "mm200777",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد محمد یسرى محمد جمعة سلیم",
    "id": "252100773",
    "username": "sds-2026-2633",
    "password": "mm812633",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد محمود عبدالجلیل عبدالله الشربینى",
    "id": "252100774",
    "username": "sds-2026-4197",
    "password": "mm804197",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد محمود عبدالعظیم محمد أحمد",
    "id": "252100775",
    "username": "sds-2026-1218",
    "password": "mm311218",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد محمود محمد محمد طلبھ",
    "id": "252100776",
    "username": "sds-2026-1636",
    "password": "mm311636",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد محمود مستجیر محمد عبد العال",
    "id": "252100777",
    "username": "sds-2026-0099",
    "password": "mm300099",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد مراد ابراھیم الدسوقى مصطفى القیعى",
    "id": "252100779",
    "username": "sds-2026-0071",
    "password": "mm200071",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد مصطفى عطیة محمد ابوالفتوح",
    "id": "252100780",
    "username": "sds-2026-0335",
    "password": "mm900335",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد منتصر سید عبد الحلیم عیسى",
    "id": "252101100",
    "username": "sds-2026-0157",
    "password": "mm900157",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد منتصر كامل مراد",
    "id": "252100781",
    "username": "sds-2026-0278",
    "password": "mm900278",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد منصور محمد محمد احمد",
    "id": "252100782",
    "username": "sds-2026-3153",
    "password": "mm303153",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد نادر عباس محمد شحاتھ",
    "id": "252100783",
    "username": "sds-2026-0239",
    "password": "mn300239",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد ھانى سعد على الشربینى",
    "id": "252100784",
    "username": "sds-2026-0735",
    "password": "mx200735",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد ھانى فوزى ابراھیم جاد محمد",
    "id": "252100785",
    "username": "sds-2026-0434",
    "password": "mx300434",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد ھانى محمد سعد امین",
    "id": "252100786",
    "username": "sds-2026-0073",
    "password": "mx300073",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد ھانى محمد عبده حلبى",
    "id": "252100787",
    "username": "sds-2026-3215",
    "password": "mx303215",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد ھشام احمد محمداحمد",
    "id": "252100788",
    "username": "sds-2026-2955",
    "password": "mx302955",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد وائل فتحى احمد محمود",
    "id": "252100789",
    "username": "sds-2026-0391",
    "password": "mw900391",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمد یاسر یسرى مدبولى عبدالله",
    "id": "252100797",
    "username": "sds-2026-0391",
    "password": "mx900391",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود احمد احمد خلیل شتا",
    "id": "252100798",
    "username": "sds-2026-3712",
    "password": "ma303712",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود احمد محمود احمد محمد",
    "id": "252100799",
    "username": "sds-2026-2331",
    "password": "ma302331",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود اسلام محمود محمد عبد الحلیم",
    "id": "252100800",
    "username": "sds-2026-0476",
    "password": "ma300476",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود السید احمد محمد محمد",
    "id": "252100801",
    "username": "sds-2026-0235",
    "password": "ma300235",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود السید محمود یونس عبدالنبى",
    "id": "252100802",
    "username": "sds-2026-2994",
    "password": "ma302994",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود بشرى حسین محمد احمد",
    "id": "252100803",
    "username": "sds-2026-1396",
    "password": "mb901396",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود جمال حلمى ابراھیم سالم",
    "id": "252100804",
    "username": "sds-2026-3393",
    "password": "mj303393",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود حمدى محمود على على",
    "id": "252100806",
    "username": "sds-2026-0595",
    "password": "mh900595",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود رفاعى محمد رفاعى محمد",
    "id": "252100807",
    "username": "sds-2026-3217",
    "password": "mr313217",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود سعید حسن عبدالسلام مرسى",
    "id": "252100808",
    "username": "sds-2026-1519",
    "password": "ms901519",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود عبدالرحمن سالم حسن متولى",
    "id": "252100812",
    "username": "sds-2026-6475",
    "password": "ma306475",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود عبدالعزیز عبدالمولى محمد مصطفى",
    "id": "252100813",
    "username": "sds-2026-5454",
    "password": "ma305454",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود عید المتولى ابراھیم والى",
    "id": "252100815",
    "username": "sds-2026-3451",
    "password": "ma203451",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود محمد ابراھیم مھدى صالح",
    "id": "252101116",
    "username": "sds-2026-4051",
    "password": "mm304051",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود محمد حسین نجاح محمد حسین نجم",
    "id": "252100817",
    "username": "sds-2026-5953",
    "password": "mm355953",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود محمد عبدالعال السید اسماعیل",
    "id": "252100820",
    "username": "sds-2026-3794",
    "password": "mm303794",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود محمد فتحى درویش عطیھ",
    "id": "252100822",
    "username": "sds-2026-0171",
    "password": "mm900171",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود محمد فتحى محمد نظیم مصطفى",
    "id": "252100823",
    "username": "sds-2026-1839",
    "password": "mm311839",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود محمد محمود عبدالرحمن عبدالكریم",
    "id": "252100825",
    "username": "sds-2026-0433",
    "password": "mm900433",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "محمود محمد محمود على موسى",
    "id": "252100827",
    "username": "sds-2026-7956",
    "password": "mm357956",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مروان محمود ماھر كامل محمود",
    "id": "252100833",
    "username": "sds-2026-3174",
    "password": "mm403174",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مروان ولید احمد السید محمود الصریف",
    "id": "252100836",
    "username": "sds-2026-0535",
    "password": "mw900535",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مروه اسامھ شعبان السید السید",
    "id": "252100837",
    "username": "sds-2026-5805",
    "password": "ma305805",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مروه ھاشم محمد حسین على",
    "id": "252100838",
    "username": "sds-2026-4744",
    "password": "mx334744",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم ابراھیم جاد الحق احمد الفولى",
    "id": "252100840",
    "username": "sds-2026-4421",
    "password": "ma304421",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم احمد امین على مقلد",
    "id": "252100842",
    "username": "sds-2026-3465",
    "password": "ma303465",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم احمد صلاح محمود الدسوقى مجاھد",
    "id": "252100843",
    "username": "sds-2026-1521",
    "password": "ma201521",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم السید محمد رفعت محمد",
    "id": "252100847",
    "username": "sds-2026-0587",
    "password": "ma300587",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم السید محمد موسى محمد",
    "id": "252100848",
    "username": "sds-2026-6283",
    "password": "ma306283",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم السید مسعد السید موسى",
    "id": "252100849",
    "username": "sds-2026-1444",
    "password": "ma301444",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم انسى عزیز توفیق",
    "id": "252101138",
    "username": "sds-2026-2568",
    "password": "ma302568",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم حمدى حسین سید حسنین",
    "id": "252100852",
    "username": "sds-2026-2501",
    "password": "mh402501",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم ربیع ابراھیم الدسوقي عبدالرحمن",
    "id": "252100853",
    "username": "sds-2026-1508",
    "password": "mr301508",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم سامح محمد عبدالعزیز على",
    "id": "252100854",
    "username": "sds-2026-1507",
    "password": "ms301507",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم سمیر الحسینى محمد سید احمد",
    "id": "252100855",
    "username": "sds-2026-3026",
    "password": "ms303026",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم شعبان محمد دسوقى ابراھیم",
    "id": "252100856",
    "username": "sds-2026-2944",
    "password": "ms902944",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم محمد عبدالمنعم محمد",
    "id": "252100864",
    "username": "sds-2026-3429",
    "password": "mm303429",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم محمود فاروق على سعد",
    "id": "252100866",
    "username": "sds-2026-0568",
    "password": "mm900568",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم معتز عبد المنعم محمد عبده",
    "id": "252101095",
    "username": "sds-2026-0307",
    "password": "mm300307",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم ھانى محمد ابراھیم ضیف",
    "id": "252100868",
    "username": "sds-2026-0042",
    "password": "mx300042",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم ھیثم محمد فخرى المتولى جمعھ",
    "id": "252100869",
    "username": "sds-2026-0424",
    "password": "mx300424",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم ولید فوزى على العزبى",
    "id": "252100871",
    "username": "sds-2026-0086",
    "password": "mw300086",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مریم ولید محمد جابر حماد",
    "id": "252101167",
    "username": "sds-2026-0149",
    "password": "mw900149",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مصطفى اسماعیل عبدالله احمد القاضى",
    "id": "252100875",
    "username": "sds-2026-8193",
    "password": "ma308193",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مصطفى فكري حسني محمود محمد",
    "id": "252100880",
    "username": "sds-2026-5017",
    "password": "mf305017",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مصطفى محمد محمود محمد ابراھیم",
    "id": "252100883",
    "username": "sds-2026-0235",
    "password": "mm900235",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مصطفى محمد مصطفى محمد عبدالله",
    "id": "252100885",
    "username": "sds-2026-0411",
    "password": "mm300411",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "معاذ محمد احمد محمد احمد",
    "id": "252100887",
    "username": "sds-2026-0457",
    "password": "mm900457",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "معاذ محمد السید عبدالرحیم اللیلى",
    "id": "252100888",
    "username": "sds-2026-0171",
    "password": "mm900171",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "معتز عادل موسى ابراھیم سالم",
    "id": "252100889",
    "username": "sds-2026-2695",
    "password": "ma312695",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ملك احمد احمد مصطفى الباجورى",
    "id": "252100893",
    "username": "sds-2026-0449",
    "password": "ma710449",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ملك سالم سالم محمد مصبح",
    "id": "252100898",
    "username": "sds-2026-2167",
    "password": "ms302167",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ملك عادل على محارب",
    "id": "252100899",
    "username": "sds-2026-0305",
    "password": "ma400305",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ملك محمد السید احمد عبد العال",
    "id": "252100902",
    "username": "sds-2026-0287",
    "password": "mm300287",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ملك ھانى احمد السید سالم",
    "id": "252100907",
    "username": "sds-2026-5829",
    "password": "mx305829",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منار محمد مخیمر عبدالعلیم محمد",
    "id": "252100909",
    "username": "sds-2026-0522",
    "password": "mm900522",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منال متولى اسماعیل حسن محمد احمد",
    "id": "252100910",
    "username": "sds-2026-6501",
    "password": "mm306501",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منال مدحت سید محمود محمد",
    "id": "252100911",
    "username": "sds-2026-0422",
    "password": "mm900422",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منة الله تامر محمد حامد بدوى",
    "id": "252100912",
    "username": "sds-2026-0207",
    "password": "ma300207",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منھ احمد محمد دسوقى عطیھ",
    "id": "252100915",
    "username": "sds-2026-1661",
    "password": "ma301661",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منھ الله ایمن سالم حسن",
    "id": "252100918",
    "username": "sds-2026-3587",
    "password": "ma303587",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منھ الله على السید بكرى",
    "id": "252100919",
    "username": "sds-2026-0245",
    "password": "ma300245",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منھ الله ماھر عبدالعال محمود عبدالعال",
    "id": "252100920",
    "username": "sds-2026-3206",
    "password": "ma303206",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منھ الله محمد الحسینى ابراھیم ابراھیم",
    "id": "252100921",
    "username": "sds-2026-5043",
    "password": "ma215043",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منھ الله محمد السید مصطفى عطیھ",
    "id": "252100922",
    "username": "sds-2026-0228",
    "password": "ma900228",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منھ الله وائل احمد عامر عبدالمجید",
    "id": "252100924",
    "username": "sds-2026-0726",
    "password": "ma900726",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منھ الله ولید مصطفى یسن سرحان",
    "id": "252100925",
    "username": "sds-2026-0627",
    "password": "ma200627",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منھ المتولى المتولى ابراھیم والى",
    "id": "252100926",
    "username": "sds-2026-3605",
    "password": "ma203605",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منھ بدران السید حسن صالحة",
    "id": "252100927",
    "username": "sds-2026-1648",
    "password": "mb301648",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "منھ شاكر عبد الحمید اسماعیل عبد النبى",
    "id": "252101182",
    "username": "sds-2026-6564",
    "password": "ms306564",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مھرائیل فادي فؤاد حبیب میخائیل",
    "id": "252100934",
    "username": "sds-2026-0048",
    "password": "mf300048",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مھرائیل مراد تودري اسكندر متى",
    "id": "252100935",
    "username": "sds-2026-0049",
    "password": "mm900049",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مھند احمد محمود ابراھیم المكاوى",
    "id": "252100937",
    "username": "sds-2026-0095",
    "password": "ma300095",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مى السید احمد ابراھیم السھویتى",
    "id": "252100938",
    "username": "sds-2026-2069",
    "password": "ma302069",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مى حسن سلیمان محمود سلیمان",
    "id": "252100939",
    "username": "sds-2026-0669",
    "password": "mh900669",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مى حمدى محمد محمود ابوحامد",
    "id": "252100940",
    "username": "sds-2026-0484",
    "password": "mh300484",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مى عبدالحكیم عبدالجلیل أحمد جبر",
    "id": "252100941",
    "username": "sds-2026-2582",
    "password": "ma302582",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مى متولى محمد كامل محمد على كاشف",
    "id": "252100942",
    "username": "sds-2026-0827",
    "password": "mm300827",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مى محمود محمد عبدالكریم محمود",
    "id": "252100943",
    "username": "sds-2026-3622",
    "password": "mm903622",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "میرا مدحت ملك فھیم ملك",
    "id": "252100947",
    "username": "sds-2026-0128",
    "password": "mm300128",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "میرنا احمد محمد محمد توفیق",
    "id": "252100949",
    "username": "sds-2026-0384",
    "password": "ma900384",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "میسون التابعى عبد السلام احمد دراھم",
    "id": "252100951",
    "username": "sds-2026-0261",
    "password": "ma300261",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "مینا یسرى بطرس وغیم",
    "id": "252100953",
    "username": "sds-2026-4277",
    "password": "mx504277",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "نادیھ احمد ابراھیم سعید ابراھیم",
    "id": "252100954",
    "username": "sds-2026-0862",
    "password": "na300862",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ناریمان محمد اسماعیل طلبھ عطیة",
    "id": "252100955",
    "username": "sds-2026-1883",
    "password": "nm301883",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ناریمان محمد المرسي احمد مجاھد",
    "id": "252100956",
    "username": "sds-2026-1202",
    "password": "nm301202",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ناریمان ولید رجب على رحومھ",
    "id": "252100957",
    "username": "sds-2026-3508",
    "password": "nw303508",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "نبیل حسام حسنى سالم مصطفى عبد الفتاح",
    "id": "252100958",
    "username": "sds-2026-0811",
    "password": "nh800811",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ندا السید حسن على",
    "id": "252100960",
    "username": "sds-2026-4044",
    "password": "na304044",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ندى احمد محمد غزال حسن السمرى",
    "id": "252100962",
    "username": "sds-2026-2009",
    "password": "na202009",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ندى ایمن ابراھیم محمد محمد",
    "id": "252100963",
    "username": "sds-2026-1384",
    "password": "na301384",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ندى عماد علام محمد جابر علام",
    "id": "252101112",
    "username": "sds-2026-0562",
    "password": "na600562",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ندى محمد زین عبد الوھاب مصطفى",
    "id": "252101131",
    "username": "sds-2026-0081",
    "password": "nm400081",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ندى مدحت احمد عبد الله احمد",
    "id": "252100968",
    "username": "sds-2026-9888",
    "password": "nm309888",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ندى ھانى عبد الحمید ابراھیم الزیر",
    "id": "252100969",
    "username": "sds-2026-2167",
    "password": "nx202167",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ندى یحیى عبدالرحمن سالم ابوالعنین",
    "id": "252100970",
    "username": "sds-2026-4524",
    "password": "nx904524",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "نورا احمد فكرى عبدالرحمن على",
    "id": "252100976",
    "username": "sds-2026-9608",
    "password": "na309608",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "نورا على فتحى محمد ابراھیم",
    "id": "252100977",
    "username": "sds-2026-3163",
    "password": "na203163",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "نورالدین محمد نصار سالم",
    "id": "252100978",
    "username": "sds-2026-0999",
    "password": "nm800999",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "نوران على فوزى محمد رشاد حواس",
    "id": "252100979",
    "username": "sds-2026-3887",
    "password": "na303887",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "نورھان ابراھیم عبد الرازق ابراھیم حمود",
    "id": "252100980",
    "username": "sds-2026-3488",
    "password": "na603488",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "نیجار عبدالله عبدالمنعم محمد مصطفى",
    "id": "252100983",
    "username": "sds-2026-8162",
    "password": "na308162",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھاجر احمد السید صالح غریب",
    "id": "252100985",
    "username": "sds-2026-0469",
    "password": "xa900469",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھاجر رجب عبدالعزیز ابراھیم محمد",
    "id": "252100986",
    "username": "sds-2026-5288",
    "password": "xr305288",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھاجر محمد عبد الموجود نعمان ابراھیم",
    "id": "252100989",
    "username": "sds-2026-1588",
    "password": "xm221588",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھدى عادل رضوان سویلم سالمان",
    "id": "252100993",
    "username": "sds-2026-4745",
    "password": "xa904745",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھشام عبد الرحمن شحاتھ السید عبد الرحمن",
    "id": "252100994",
    "username": "sds-2026-0594",
    "password": "xa300594",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھشام محمد عرفھ سلیمان بدوى",
    "id": "252100995",
    "username": "sds-2026-0657",
    "password": "xm900657",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھمسھ البغدادى أحمد ابراھیم النقیب",
    "id": "252100996",
    "username": "sds-2026-0325",
    "password": "xa100325",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھنا اسماعیل محمود محمد حسن",
    "id": "252100998",
    "username": "sds-2026-3123",
    "password": "xa303123",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھنا طارق عبدالعزیز معوض حامد",
    "id": "252101000",
    "username": "sds-2026-0087",
    "password": "xt900087",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھنا عادل احمد احمدعثمان",
    "id": "252101001",
    "username": "sds-2026-2668",
    "password": "xa302668",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھنا فھمي عبدالعال خلیل نجم",
    "id": "252101002",
    "username": "sds-2026-5106",
    "password": "xf305106",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھنا محمد یوسف محمد احمد الریس",
    "id": "252101003",
    "username": "sds-2026-1785",
    "password": "xm201785",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھنا محمود عبدالجواد محمد عوض",
    "id": "252101004",
    "username": "sds-2026-0905",
    "password": "xm300905",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھنا نور سعد حسن حسین",
    "id": "252101005",
    "username": "sds-2026-1788",
    "password": "xn301788",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھند شاھین محمد عبدالحمید سلامھ",
    "id": "252101009",
    "username": "sds-2026-0809",
    "password": "xs900809",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "ھنیھ ابراھیم مصبح ابراھیم عبد الرحیم",
    "id": "252101010",
    "username": "sds-2026-5101",
    "password": "xa205101",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "وفاء اسامة محمد عبدالعال حسن",
    "id": "252101013",
    "username": "sds-2026-3403",
    "password": "wa303403",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یارا ابوالمجد عبدالغنى ابوالمجد احمد",
    "id": "252101016",
    "username": "sds-2026-1927",
    "password": "xa401927",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یارا شریف سمیر عید عواد سالم",
    "id": "252101018",
    "username": "sds-2026-0104",
    "password": "xs900104",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یارا شریف صلاح محمد احمد",
    "id": "252101019",
    "username": "sds-2026-0683",
    "password": "xs900683",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یاسمین السید ابراھیم محمد ابراھیم",
    "id": "252101023",
    "username": "sds-2026-6366",
    "password": "xa306366",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یاسمین شحاتة عبدالھادى عثمان",
    "id": "252101024",
    "username": "sds-2026-0886",
    "password": "xs800886",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یاسمین مصباح عبدالحمید اسماعیل حسین",
    "id": "252101025",
    "username": "sds-2026-2043",
    "password": "xm302043",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یاسمین مصطفى محمود محمود السید",
    "id": "252101027",
    "username": "sds-2026-2326",
    "password": "xm502326",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف اسامھ كتانھ امین كتانھ",
    "id": "252101031",
    "username": "sds-2026-0134",
    "password": "xa300134",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف اكرم محمود عید السید",
    "id": "252101032",
    "username": "sds-2026-0191",
    "password": "xa300191",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف توفیق احمد محمد العوضى",
    "id": "252101113",
    "username": "sds-2026-2477",
    "password": "xt202477",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف حازم عبد الرحمن محمد محمد عیسى",
    "id": "252101034",
    "username": "sds-2026-0236",
    "password": "xh300236",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف خیرى محمود محمد الشھیدى",
    "id": "252101137",
    "username": "sds-2026-2456",
    "password": "xk302456",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف شعبان على عبد العال سید احمد",
    "id": "252101041",
    "username": "sds-2026-4379",
    "password": "xs304379",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف صبرى شكرى على ربیع",
    "id": "252101042",
    "username": "sds-2026-2494",
    "password": "xs312494",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف عبد العزیز عبده احمد اللیثى",
    "id": "252101121",
    "username": "sds-2026-0931",
    "password": "xa800931",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف عبدالرؤف السید یوسف محمد",
    "id": "252101044",
    "username": "sds-2026-0654",
    "password": "xa310654",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف مجدى الحسیني ابو العنین حموده",
    "id": "252101046",
    "username": "sds-2026-0156",
    "password": "xm300156",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف محمد احمد محمد الصادق",
    "id": "252101048",
    "username": "sds-2026-0397",
    "password": "xm500397",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف محمد الشحات محمد الشحات",
    "id": "252101049",
    "username": "sds-2026-3515",
    "password": "xm303515",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف محمد عادل حمد نصر",
    "id": "252101050",
    "username": "sds-2026-3178",
    "password": "xm303178",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف محمد منصور محمد عیداروس",
    "id": "252101053",
    "username": "sds-2026-1832",
    "password": "xm301832",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف محمود عبدالمجید عبدالمعطى علیوه",
    "id": "252101055",
    "username": "sds-2026-3738",
    "password": "xm303738",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف نجاح جوده محمود على",
    "id": "252101058",
    "username": "sds-2026-3215",
    "password": "xn203215",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف ھانى ثابت زكى مكسیموس",
    "id": "252101059",
    "username": "sds-2026-1094",
    "password": "xx401094",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  },
  {
    "name": "یوسف یاسر عبدالعزیز محمد ابراھیم",
    "id": "252101060",
    "username": "sds-2026-8917",
    "password": "xx318917",
    "points": 100,
    "zone": "GREEN",
    "gpa": null,
    "attendance": 100
  }
];

export default students;
