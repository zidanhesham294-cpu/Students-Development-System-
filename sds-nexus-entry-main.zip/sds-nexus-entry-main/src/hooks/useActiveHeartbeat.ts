import { useEffect } from "react";
import { sendHeartbeat } from "@/lib/adminStore";

/** Sends heartbeat every 20s so this user shows up in "النشطون الآن". */
export function useActiveHeartbeat(_username: string | null | undefined) {
  useEffect(() => {
    let stopped = false;
    const beat = () => { if (!stopped) void sendHeartbeat(); };
    beat();
    const iv = window.setInterval(beat, 20_000);
    const onFocus = () => beat();
    window.addEventListener("focus", onFocus);
    return () => {
      stopped = true;
      window.clearInterval(iv);
      window.removeEventListener("focus", onFocus);
    };
  }, []);
}
