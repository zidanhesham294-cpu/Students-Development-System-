import { useEffect, useState } from "react";
import { getStudentLive, subscribeState } from "@/lib/adminStore";
import type { Student } from "@/lib/auth";

/** Returns the always-fresh student object (points + zone reflect admin changes). */
export function useLiveStudent(id: string | null | undefined): Student | null {
  const [s, setS] = useState<Student | null>(() => (id ? getStudentLive(id) : null));

  useEffect(() => {
    if (!id) {
      setS(null);
      return;
    }
    setS(getStudentLive(id));
    const unsub = subscribeState(() => setS(getStudentLive(id)));
    return unsub;
  }, [id]);

  return s;
}
