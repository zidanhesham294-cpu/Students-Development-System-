import { supabase } from "@/integrations/supabase/client";
import { getSessionToken, zoneForPoints, type Student } from "@/lib/auth";
import * as sds from "@/lib/sds.functions";
import type { RealtimeChannel } from "@supabase/supabase-js";

export type LogEntry = {
  id: string;
  date: string; // YYYY/MM/DD
  reason: string;
  delta: number;
};

type StudentState = { points: number; zone: string; logs: LogEntry[] };

// ---- In-memory caches, filled by realtime + initial fetches ----
const studentsById = new Map<string, Student>();
const logsByStudent = new Map<string, LogEntry[]>();
const activeUsers = new Map<string, { name?: string; last_seen: number }>();

const STATE_EVT = "sds:state-changed";
const ACTIVE_EVT = "sds:active-changed";

function emitState() {
  if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent(STATE_EVT));
}
function emitActive() {
  if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent(ACTIVE_EVT));
}

// ---- Boot: initial fetch + realtime channels (singleton per tab) ----
let booted = false;
let studentsChan: RealtimeChannel | null = null;
let logsChan: RealtimeChannel | null = null;
let activeChan: RealtimeChannel | null = null;

async function boot() {
  if (booted || typeof window === "undefined") return;
  booted = true;
  const [{ data: sts }, { data: lgs }, { data: acts }] = await Promise.all([
    supabase.from("students").select("id, admin_id, name, username, points, zone, gpa, attendance, subjects").order("admin_id"),
    supabase.from("behavioral_logs").select("id, student_id, delta, reason, created_at").order("created_at", { ascending: false }),
    supabase.from("active_sessions").select("username, name, last_seen"),
  ]);
  (sts ?? []).forEach((s) => studentsById.set(s.id, s as Student));
  (lgs ?? []).forEach((l) => {
    const arr = logsByStudent.get(l.student_id) ?? [];
    arr.push({
      id: l.id,
      date: new Date(l.created_at).toISOString().slice(0, 10).replace(/-/g, "/"),
      reason: l.reason,
      delta: l.delta,
    });
    logsByStudent.set(l.student_id, arr);
  });
  (acts ?? []).forEach((a) => activeUsers.set(a.username, { name: a.name ?? undefined, last_seen: new Date(a.last_seen).getTime() }));
  emitState();
  emitActive();

  studentsChan = supabase.channel("sds-students")
    .on("postgres_changes", { event: "*", schema: "public", table: "students" }, (payload) => {
      const row = (payload.new ?? payload.old) as Student | undefined;
      if (!row) return;
      if (payload.eventType === "DELETE") studentsById.delete(row.id);
      else studentsById.set(row.id, payload.new as Student);
      emitState();
    }).subscribe();

  logsChan = supabase.channel("sds-logs")
    .on("postgres_changes", { event: "*", schema: "public", table: "behavioral_logs" }, (payload) => {
      if (payload.eventType === "INSERT") {
        const l = payload.new as { id: string; student_id: string; delta: number; reason: string; created_at: string };
        const arr = logsByStudent.get(l.student_id) ?? [];
        arr.unshift({ id: l.id, date: new Date(l.created_at).toISOString().slice(0, 10).replace(/-/g, "/"), reason: l.reason, delta: l.delta });
        logsByStudent.set(l.student_id, arr);
      } else if (payload.eventType === "UPDATE") {
        const l = payload.new as { id: string; student_id: string; delta: number; reason: string };
        const arr = logsByStudent.get(l.student_id) ?? [];
        const idx = arr.findIndex((x) => x.id === l.id);
        if (idx >= 0) arr[idx] = { ...arr[idx], delta: l.delta, reason: l.reason };
        logsByStudent.set(l.student_id, arr);
      } else if (payload.eventType === "DELETE") {
        const l = payload.old as { id: string; student_id: string };
        const arr = logsByStudent.get(l.student_id) ?? [];
        logsByStudent.set(l.student_id, arr.filter((x) => x.id !== l.id));
      }
      emitState();
    }).subscribe();

  activeChan = supabase.channel("sds-active")
    .on("postgres_changes", { event: "*", schema: "public", table: "active_sessions" }, (payload) => {
      if (payload.eventType === "DELETE") {
        const row = payload.old as { username: string };
        activeUsers.delete(row.username);
      } else {
        const row = payload.new as { username: string; name?: string; last_seen: string };
        activeUsers.set(row.username, { name: row.name, last_seen: new Date(row.last_seen).getTime() });
      }
      emitActive();
    }).subscribe();
}

// Fire and forget on module load in the browser.
if (typeof window !== "undefined") void boot();

// ---- Public API (kept sync to preserve existing screens) ----
export function subscribeState(cb: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  void boot();
  const h = () => cb();
  window.addEventListener(STATE_EVT, h);
  return () => window.removeEventListener(STATE_EVT, h);
}

export function subscribeActiveUsers(cb: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  void boot();
  const h = () => cb();
  window.addEventListener(ACTIVE_EVT, h);
  return () => window.removeEventListener(ACTIVE_EVT, h);
}

export function getAllStudents(): Student[] {
  return Array.from(studentsById.values());
}

export function getStudentLive(id: string): Student | null {
  return studentsById.get(id) ?? null;
}

export function getStudentByUsername(username: string): Student | null {
  const lc = username.toLowerCase();
  for (const s of studentsById.values()) if (s.username.toLowerCase() === lc) return s;
  return null;
}

export function getStudentState(id: string): StudentState {
  const s = studentsById.get(id);
  const points = s?.points ?? 100;
  return { points, zone: zoneForPoints(points).zone, logs: logsByStudent.get(id) ?? [] };
}

export const ACTIVE_WINDOW_MS = 60_000;
export function getActiveUsers(): string[] {
  const cutoff = Date.now() - ACTIVE_WINDOW_MS;
  const out: string[] = [];
  for (const [u, v] of activeUsers.entries()) if (v.last_seen >= cutoff) out.push(u);
  return out;
}
export function getActiveUserRows(): { username: string; name?: string }[] {
  const cutoff = Date.now() - ACTIVE_WINDOW_MS;
  const out: { username: string; name?: string }[] = [];
  for (const [u, v] of activeUsers.entries()) if (v.last_seen >= cutoff) out.push({ username: u, name: v.name });
  return out;
}

// ---- Writes: go through server functions ----
export async function addPointChange(id: string, delta: number, reason: string): Promise<StudentState> {
  const token = getSessionToken() ?? "";
  await sds.addLog({ data: { token, studentId: id, delta, reason: reason.trim() || "بدون سبب" } });
  return getStudentState(id);
}
export async function updateLog(id: string, logId: string, patch: Partial<Pick<LogEntry, "delta" | "reason">>): Promise<StudentState> {
  const token = getSessionToken() ?? "";
  const cur = (logsByStudent.get(id) ?? []).find((l) => l.id === logId);
  const delta = patch.delta ?? cur?.delta ?? 0;
  const reason = patch.reason ?? cur?.reason ?? "";
  await sds.updateLogFn({ data: { token, logId, delta, reason } });
  return getStudentState(id);
}
export async function deleteLog(id: string, logId: string): Promise<StudentState> {
  const token = getSessionToken() ?? "";
  await sds.deleteLogFn({ data: { token, logId } });
  return getStudentState(id);
}

// ---- Legacy admin flag helpers (for back-compat with existing route guards) ----
export function isAdmin(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const raw = window.localStorage.getItem("sds.currentUser");
    if (!raw) return false;
    const u = JSON.parse(raw) as { role?: string };
    return u.role === "admin";
  } catch {
    return false;
  }
}
export function clearAdmin() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem("sds.session");
  window.localStorage.removeItem("sds.currentUser");
}

// Heartbeat helper
export async function sendHeartbeat() {
  const token = getSessionToken();
  if (!token) return;
  try { await sds.heartbeat({ data: { token } }); } catch { /* noop */ }
}
