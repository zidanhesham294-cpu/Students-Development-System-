import { supabase } from "@/integrations/supabase/client";

export type Student = {
  id: string;
  name: string;
  admin_id: string;
  username: string;
  password?: string;
  points: number;
  zone: string;
  gpa: number | null;
  attendance: number;
  subjects?: unknown;
};

// Legacy field alias so existing code that reads student.id (as admin number) keeps working.
// Now we return admin_id in that position for display consistency.
// Components that need the DB uuid should use `.id` — we keep `.id` = uuid, and expose `admin_id` explicitly.

const CURRENT_KEY = "sds.currentUser";
const TOKEN_KEY = "sds.session";
const REMEMBER_KEY = "sds.remember";

export type CurrentUser = {
  id: string; // uuid
  username: string;
  name: string;
  role: "student" | "teacher" | "admin";
};

export function setSession(token: string, user: CurrentUser) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(TOKEN_KEY, token);
  window.localStorage.setItem(CURRENT_KEY, JSON.stringify(user));
}
export function getSessionToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(TOKEN_KEY);
}
export function getCurrentUser(): CurrentUser | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(CURRENT_KEY);
    return raw ? (JSON.parse(raw) as CurrentUser) : null;
  } catch {
    return null;
  }
}
export function clearSession() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(TOKEN_KEY);
  window.localStorage.removeItem(CURRENT_KEY);
  window.localStorage.removeItem(REMEMBER_KEY);
}
export function setRemember(v: boolean) {
  if (typeof window === "undefined") return;
  if (v) window.localStorage.setItem(REMEMBER_KEY, "1");
  else window.localStorage.removeItem(REMEMBER_KEY);
}
export function getRemember(): boolean {
  if (typeof window === "undefined") return false;
  return window.localStorage.getItem(REMEMBER_KEY) === "1";
}

// -------- Back-compat helpers used by existing screens --------
export function getCurrentStudent(): (Student & { admin_id: string }) | null {
  const u = getCurrentUser();
  if (!u || u.role !== "student") return null;
  // Look up cached; fall back to null. Callers must handle null.
  return {
    id: u.id,
    name: u.name,
    username: u.username,
    admin_id: "",
    points: 100,
    zone: "GREEN",
    gpa: null,
    attendance: 100,
  };
}
export function clearCurrentStudent() {
  clearSession();
}

// Fetch live student from cloud by uuid.
export async function fetchStudent(id: string): Promise<Student | null> {
  const { data } = await supabase.from("students")
    .select("id, admin_id, name, username, points, zone, gpa, attendance, subjects")
    .eq("id", id).maybeSingle();
  return data as Student | null;
}

export function zoneForPoints(points: number): {
  zone: string;
  color: string;
  glow?: boolean;
  prestige: boolean;
} {
  if (points >= 151) return { zone: "SHINY GOLD", color: "#ffd447", glow: true, prestige: true };
  if (points >= 101) return { zone: "GOLD", color: "#e6b53a", prestige: true };
  if (points >= 71) return { zone: "GREEN", color: "#22c55e", prestige: false };
  if (points >= 41) return { zone: "BLUE", color: "#3b82f6", prestige: false };
  return { zone: "RED", color: "#ef4444", prestige: false };
}

export function isAdmin(): boolean {
  const u = getCurrentUser();
  return !!u && u.role === "admin";
}
export function isTeacher(): boolean {
  const u = getCurrentUser();
  return !!u && u.role === "teacher";
}
