import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

// ---------- LOGIN ----------
export const login = createServerFn({ method: "POST" })
  .inputValidator((d: { role: "student" | "teacher" | "admin"; username: string; password: string }) =>
    z.object({
      role: z.enum(["student", "teacher", "admin"]),
      username: z.string().min(1).max(120),
      password: z.string().min(1).max(120),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { signSession } = await import("./session.server");
    const u = data.username.trim();
    const p = data.password.trim();

    // Role gate by username pattern
    const looksAdmin = /^ZIDAN-SDS-/i.test(u) || u.toUpperCase() === "ZIDAN-SDS-2026";
    const looksTeacher = /^TEA-SDS-/i.test(u);
    const looksStudent = /^sds-\d{4}-\d+/i.test(u);

    if (data.role === "admin") {
      if (!looksAdmin) return { error: "هذا التبويب مخصص للإدارة فقط" as string };
      const { data: row } = await supabaseAdmin
        .from("admins").select("id, name, username, password").eq("username", u).maybeSingle();
      if (!row || row.password !== p) return { error: "بيانات الدخول غير صحيحة" };
      const exp = Date.now() + 30 * 24 * 3600 * 1000;
      return { token: signSession({ id: row.id, username: row.username, name: row.name, role: "admin", exp }), role: "admin" as const, id: row.id, name: row.name, username: row.username };
    }

    if (data.role === "teacher") {
      if (!looksTeacher) return { error: "هذا التبويب مخصص للمعلمين فقط" };
      const { data: row } = await supabaseAdmin
        .from("teachers").select("id, name, username, password").eq("username", u).maybeSingle();
      if (!row || row.password !== p) return { error: "بيانات الدخول غير صحيحة" };
      const exp = Date.now() + 30 * 24 * 3600 * 1000;
      return { token: signSession({ id: row.id, username: row.username, name: row.name, role: "teacher", exp }), role: "teacher" as const, id: row.id, name: row.name, username: row.username };
    }

    // student
    if (looksAdmin) return { error: "هذا الحساب مخصص للإدارة فقط، يرجى اختيار تبويب مدير" };
    if (looksTeacher) return { error: "هذا الحساب مخصص للمعلمين فقط، يرجى اختيار تبويب معلم" };
    if (!looksStudent) return { error: "اسم المستخدم غير صحيح" };
    const { data: row } = await supabaseAdmin
      .from("students").select("id, admin_id, name, username, password, points, zone, gpa, attendance").eq("username", u.toLowerCase()).maybeSingle();
    if (!row || row.password !== p) return { error: "اسم المستخدم أو كلمة المرور غير صحيحة." };
    const exp = Date.now() + 30 * 24 * 3600 * 1000;
    return {
      token: signSession({ id: row.id, username: row.username, name: row.name, role: "student", exp }),
      role: "student" as const,
      name: row.name,
      username: row.username,
      student: row,
    };
  });

// ---------- HEARTBEAT ----------
export const heartbeat = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string }) => z.object({ token: z.string() }).parse(d))
  .handler(async ({ data }) => {
    const { verifySession } = await import("./session.server");
    const s = verifySession(data.token);
    if (!s) return { ok: false };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("active_sessions").upsert(
      { username: s.username, role: s.role, name: s.name, last_seen: new Date().toISOString() },
      { onConflict: "username" },
    );
    return { ok: true };
  });

export const signOut = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string }) => z.object({ token: z.string() }).parse(d))
  .handler(async ({ data }) => {
    const { verifySession } = await import("./session.server");
    const s = verifySession(data.token);
    if (!s) return { ok: true };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("active_sessions").delete().eq("username", s.username);
    return { ok: true };
  });

// ---------- ADMIN: POINTS / LOGS ----------
function zoneFor(points: number): string {
  if (points >= 151) return "SHINY GOLD";
  if (points >= 101) return "GOLD";
  if (points >= 71) return "GREEN";
  if (points >= 41) return "BLUE";
  return "RED";
}

async function requireRole(token: string, role: "admin" | "teacher" | "student") {
  const { verifySession } = await import("./session.server");
  const s = verifySession(token);
  if (!s || s.role !== role) throw new Error("Unauthorized");
  return s;
}

export const addLog = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; studentId: string; delta: number; reason: string }) =>
    z.object({ token: z.string(), studentId: z.string().uuid(), delta: z.number().int(), reason: z.string().min(1).max(500) }).parse(d),
  )
  .handler(async ({ data }) => {
    await requireRole(data.token, "admin");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: st } = await supabaseAdmin.from("students").select("points").eq("id", data.studentId).single();
    const cur = st?.points ?? 100;
    const next = Math.max(0, Math.min(200, cur + data.delta));
    await supabaseAdmin.from("behavioral_logs").insert({ student_id: data.studentId, delta: data.delta, reason: data.reason });
    await supabaseAdmin.from("students").update({ points: next, zone: zoneFor(next) }).eq("id", data.studentId);
    return { ok: true, points: next };
  });

export const updateLogFn = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; logId: string; delta: number; reason: string }) =>
    z.object({ token: z.string(), logId: z.string().uuid(), delta: z.number().int(), reason: z.string().min(1).max(500) }).parse(d),
  )
  .handler(async ({ data }) => {
    await requireRole(data.token, "admin");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: old } = await supabaseAdmin.from("behavioral_logs").select("student_id, delta").eq("id", data.logId).single();
    if (!old) return { ok: false };
    const diff = data.delta - old.delta;
    const { data: st } = await supabaseAdmin.from("students").select("points").eq("id", old.student_id).single();
    const cur = st?.points ?? 100;
    const next = Math.max(0, Math.min(200, cur + diff));
    await supabaseAdmin.from("behavioral_logs").update({ delta: data.delta, reason: data.reason }).eq("id", data.logId);
    await supabaseAdmin.from("students").update({ points: next, zone: zoneFor(next) }).eq("id", old.student_id);
    return { ok: true };
  });

export const deleteLogFn = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; logId: string }) =>
    z.object({ token: z.string(), logId: z.string().uuid() }).parse(d),
  )
  .handler(async ({ data }) => {
    await requireRole(data.token, "admin");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: old } = await supabaseAdmin.from("behavioral_logs").select("student_id, delta").eq("id", data.logId).single();
    if (!old) return { ok: false };
    const { data: st } = await supabaseAdmin.from("students").select("points").eq("id", old.student_id).single();
    const cur = st?.points ?? 100;
    const next = Math.max(0, Math.min(200, cur - old.delta));
    await supabaseAdmin.from("behavioral_logs").delete().eq("id", data.logId);
    await supabaseAdmin.from("students").update({ points: next, zone: zoneFor(next) }).eq("id", old.student_id);
    return { ok: true };
  });

// ---------- ADMIN: TEACHERS ----------
export const createTeacher = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; name: string; username: string; password: string }) =>
    z.object({
      token: z.string(),
      name: z.string().min(1).max(120),
      username: z.string().regex(/^TEA-SDS-\d{1,6}$/, "Username must be TEA-SDS-xxxx"),
      password: z.string().min(1).max(120),
    }).parse(d),
  )
  .handler(async ({ data }) => {
    await requireRole(data.token, "admin");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("teachers").insert({ name: data.name, username: data.username, password: data.password });
    if (error) return { ok: false, error: error.message };
    return { ok: true };
  });

export const deleteTeacher = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; teacherId: string }) =>
    z.object({ token: z.string(), teacherId: z.string().uuid() }).parse(d),
  )
  .handler(async ({ data }) => {
    await requireRole(data.token, "admin");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("teachers").delete().eq("id", data.teacherId);
    return { ok: true };
  });

// ---------- TEACHER: ROSTER ----------
export const setRoster = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; studentIds: string[] }) =>
    z.object({ token: z.string(), studentIds: z.array(z.string().uuid()).max(2000) }).parse(d),
  )
  .handler(async ({ data }) => {
    const s = await requireRole(data.token, "teacher");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Merge: insert missing rows; do not delete existing (additive per spec)
    if (data.studentIds.length === 0) return { ok: true };
    const rows = data.studentIds.map((sid) => ({ teacher_id: s.id, student_id: sid }));
    await supabaseAdmin.from("teacher_roster").upsert(rows, { onConflict: "teacher_id,student_id" });
    return { ok: true };
  });

export const removeFromRoster = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; studentId: string }) =>
    z.object({ token: z.string(), studentId: z.string().uuid() }).parse(d),
  )
  .handler(async ({ data }) => {
    const s = await requireRole(data.token, "teacher");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("teacher_roster").delete().eq("teacher_id", s.id).eq("student_id", data.studentId);
    return { ok: true };
  });

// ---------- TEACHER: ATTENDANCE SESSIONS ----------
export const startAttendanceSession = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; name: string }) =>
    z.object({ token: z.string(), name: z.string().min(1).max(200) }).parse(d),
  )
  .handler(async ({ data }) => {
    const s = await requireRole(data.token, "teacher");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Close any prior active sessions by this teacher
    await supabaseAdmin.from("attendance_sessions")
      .update({ is_active: false, closed_at: new Date().toISOString() })
      .eq("teacher_id", s.id).eq("is_active", true);
    // Generate a unique 6-digit code (retry up to 5x)
    let code = "";
    for (let i = 0; i < 5; i++) {
      code = Math.floor(100000 + Math.random() * 900000).toString();
      const { data: existing } = await supabaseAdmin.from("attendance_sessions")
        .select("id").eq("code", code).eq("is_active", true).maybeSingle();
      if (!existing) break;
    }
    const { data: session, error } = await supabaseAdmin.from("attendance_sessions")
      .insert({ teacher_id: s.id, name: data.name, code, is_active: true })
      .select("id, code, name, teacher_id, created_at, is_active").single();
    if (error || !session) return { ok: false as const, error: error?.message ?? "insert failed" };
    // Pre-populate absent records for the teacher's roster
    const { data: roster } = await supabaseAdmin.from("teacher_roster").select("student_id").eq("teacher_id", s.id);
    const rows = (roster ?? []).map((r) => ({ session_id: session.id, student_id: r.student_id, status: "absent" as const }));
    if (rows.length > 0) await supabaseAdmin.from("attendance_records").insert(rows);
    return { ok: true as const, session };
  });

export const saveAttendanceSession = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; sessionId: string }) =>
    z.object({ token: z.string(), sessionId: z.string().uuid() }).parse(d),
  )
  .handler(async ({ data }) => {
    const s = await requireRole(data.token, "teacher");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("attendance_sessions")
      .update({ is_active: false, closed_at: new Date().toISOString() })
      .eq("id", data.sessionId).eq("teacher_id", s.id);
    return { ok: true };
  });

// ---------- STUDENT: SUBMIT ATTENDANCE ----------
export const submitAttendance = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; code: string }) =>
    z.object({ token: z.string(), code: z.string().regex(/^\d{6}$/) }).parse(d),
  )
  .handler(async ({ data }) => {
    const s = await requireRole(data.token, "student");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: session } = await supabaseAdmin.from("attendance_sessions")
      .select("id, teacher_id").eq("code", data.code).eq("is_active", true).maybeSingle();
    if (!session) return { ok: false as const, error: "الكود غير صحيح أو انتهت صلاحيته" };
    // must be in that teacher's roster
    const { data: onRoster } = await supabaseAdmin.from("teacher_roster")
      .select("id").eq("teacher_id", session.teacher_id).eq("student_id", s.id).maybeSingle();
    if (!onRoster) return { ok: false as const, error: "لست ضمن قائمة هذا المعلم" };
    await supabaseAdmin.from("attendance_records").upsert(
      { session_id: session.id, student_id: s.id, status: "present", marked_at: new Date().toISOString() },
      { onConflict: "session_id,student_id" },
    );
    return { ok: true as const, sessionId: session.id };
  });
