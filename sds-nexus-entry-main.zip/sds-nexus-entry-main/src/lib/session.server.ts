import { createHmac, timingSafeEqual } from "crypto";

export type SessionPayload = {
  id: string;
  username: string;
  name: string;
  role: "student" | "teacher" | "admin";
  exp: number;
};

const SECRET = () => {
  const s = process.env.SDS_SESSION_SECRET;
  if (!s) throw new Error("SDS_SESSION_SECRET not set");
  return s;
};

function b64url(input: Buffer | string): string {
  return Buffer.from(input).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function fromB64url(input: string): Buffer {
  const s = input.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((input.length + 3) % 4);
  return Buffer.from(s, "base64");
}

export function signSession(payload: SessionPayload): string {
  const body = b64url(JSON.stringify(payload));
  const sig = b64url(createHmac("sha256", SECRET()).update(body).digest());
  return `${body}.${sig}`;
}

export function verifySession(token: string | null | undefined): SessionPayload | null {
  if (!token) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = createHmac("sha256", SECRET()).update(body).digest();
  const got = fromB64url(sig);
  if (got.length !== expected.length || !timingSafeEqual(got, expected)) return null;
  try {
    const p = JSON.parse(fromB64url(body).toString("utf8")) as SessionPayload;
    if (typeof p.exp !== "number" || Date.now() > p.exp) return null;
    return p;
  } catch {
    return null;
  }
}
