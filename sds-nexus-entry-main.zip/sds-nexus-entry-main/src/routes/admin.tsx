import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  LogOut,
  Users,
  Activity,
  Search,
  X,
  Plus,
  Minus,
  Pencil,
  Trash2,
  Save,
  ChevronLeft,
  Eye,
  GraduationCap,
  BookOpen,
  Sparkles,
} from "lucide-react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { zoneForPoints, type Student } from "@/lib/auth";
import {
  addPointChange,
  clearAdmin,
  deleteLog,
  getActiveUserRows,
  getActiveUsers,
  getAllStudents,
  getStudentState,
  isAdmin,
  subscribeActiveUsers,
  subscribeState,
  updateLog,
  type LogEntry,
} from "@/lib/adminStore";
import { useActiveHeartbeat } from "@/hooks/useActiveHeartbeat";


export const Route = createFileRoute("/admin")({
  component: AdminPage,
});

const ZONES = [
  { key: "SHINY GOLD", color: "#ffd447" },
  { key: "GOLD", color: "#e6b53a" },
  { key: "GREEN", color: "#22c55e" },
  { key: "BLUE", color: "#3b82f6" },
  { key: "RED", color: "#ef4444" },
];

function AdminPage() {
  const navigate = useNavigate();
  const [list, setList] = useState<Student[]>([]);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Student | null>(null);
  const [profileStudent, setProfileStudent] = useState<Student | null>(null);
  const [showActiveList, setShowActiveList] = useState(false);
  const [activeUsers, setActiveUsers] = useState<string[]>([]);

  useEffect(() => {
    if (!isAdmin()) {
      navigate({ to: "/" });
      return;
    }
    const refresh = () => setList(getAllStudents());
    refresh();
    const unsub = subscribeState(refresh);
    return unsub;
  }, [navigate]);

  useEffect(() => {
    const refresh = () => setActiveUsers(getActiveUsers());
    refresh();
    const unsub = subscribeActiveUsers(refresh);
    return unsub;
  }, []);

  const totalStudents = list.length;


  const zoneData = useMemo(() => {
    const counts: Record<string, number> = {};
    ZONES.forEach((z) => (counts[z.key] = 0));
    list.forEach((s) => {
      const z = zoneForPoints(s.points).zone;
      counts[z] = (counts[z] ?? 0) + 1;
    });
    return ZONES.map((z) => ({ name: z.key, value: counts[z.key], color: z.color })).filter(
      (d) => d.value > 0,
    );
  }, [list]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return list;
    return list.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.username.toLowerCase().includes(q) ||
        s.admin_id.toLowerCase().includes(q),
    );
  }, [list, query]);

  const handleLogout = () => {
    clearAdmin();
    navigate({ to: "/" });
  };

  return (
    <main
      dir="rtl"
      className="relative min-h-screen w-full overflow-hidden font-arabic text-white"
      style={{ background: "radial-gradient(ellipse at top, #12294a 0%, #0b192c 45%, #07122a 100%)" }}
    >
      <BgFx />

      <header className="relative z-10 mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 pt-6 sm:px-6 sm:pt-8">
        <div className="w-10 shrink-0 sm:w-24" />
        <div className="min-w-0 text-center">
          <div className="font-sans text-2xl font-black tracking-[0.35em] text-white text-glow sm:text-4xl sm:tracking-[0.4em]" dir="ltr">
            SDS
          </div>
          <div
            className="mt-1 font-sans font-black"
            dir="ltr"
            style={{
              fontSize: "clamp(1.1rem, 4.5vw, 2rem)",
              fontWeight: 900,
              letterSpacing: "0.5em",
              paddingRight: "0.5em",
              background:
                "linear-gradient(90deg,#fff2c9,#ffd447 35%,#c9902a 55%,#f7e4b0 80%,#fff2c9)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              filter: "drop-shadow(0 0 14px rgba(255,212,71,.45)) drop-shadow(0 0 28px rgba(201,144,42,.35))",
            }}
          >
            ZIDAN
          </div>
          <div className="mt-1 text-[9px] uppercase tracking-[0.4em] text-white/40 sm:text-[10px] sm:tracking-[0.5em]" dir="ltr">
            Director Control Center
          </div>

        </div>
        <div className="shrink-0 text-left sm:w-24">
          <button
            onClick={handleLogout}
            className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs text-white/70 backdrop-blur-md transition hover:bg-white/10 hover:text-white sm:px-4 sm:text-sm"
          >
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline">خروج</span>
          </button>
        </div>
      </header>

      <div className="relative z-10 mx-auto max-w-7xl px-3 pt-8 pb-6 sm:px-5">
        {/* Top section: stacks on mobile, two columns on tablet+ */}
        <div className="grid gap-5 grid-cols-1 md:grid-cols-2">
          <div className="flex flex-col gap-5">
            <StatCard
              icon={<Users className="h-6 w-6" />}
              label="إجمالي عدد المستخدمين"
              value={totalStudents.toLocaleString("ar-EG")}
              accent="from-[#22b8ff] to-[#38f0ff]"
            />
            <StatCard
              icon={<Activity className="h-6 w-6" />}
              label="النشطون الآن"
              value={activeUsers.length.toLocaleString("ar-EG")}
              accent="from-[#22c55e] to-[#4ade80]"
              live
              onEye={() => setShowActiveList(true)}
            />
          </div>

          {/* Pie chart — tall rectangle spanning both left cards */}
          <div className="glass-card flex h-full flex-col rounded-2xl p-5">
            <h3 className="mb-3 text-right text-sm font-bold text-white/80">توزيع النطاقات السلوكية</h3>
            <div className="min-h-[240px] flex-1">
              <ResponsiveContainer>
                <PieChart>
                  <Pie
                    data={zoneData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={88}
                    paddingAngle={2}
                    stroke="#0b192c"
                    strokeWidth={2}
                  >
                    {zoneData.map((d, i) => (
                      <Cell key={i} fill={d.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: "#0b192c",
                      border: "1px solid rgba(255,255,255,.15)",
                      borderRadius: 12,
                      color: "#fff",
                      fontFamily: "Cairo, sans-serif",
                    }}
                    formatter={(v: number, n: string) => [`${v} طالب`, n]}
                  />
                  <Legend
                    wrapperStyle={{ fontFamily: "Cairo, sans-serif", fontSize: 12, color: "#fff" }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 grid grid-cols-5 gap-1 text-center text-[10px]">
              {ZONES.map((z) => {
                const count = list.filter((s) => zoneForPoints(s.points).zone === z.key).length;
                const pct = list.length ? ((count / list.length) * 100).toFixed(1) : "0";
                return (
                  <div key={z.key} className="rounded-lg border border-white/5 bg-white/[0.03] px-1 py-1.5">
                    <div className="h-1.5 w-full rounded-full" style={{ background: z.color }} />
                    <div className="mt-1 font-bold text-white">{pct}%</div>
                    <div className="text-white/50">{count}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Master student list — full width */}
        <div className="glass-card mt-5 rounded-2xl p-3 sm:p-5">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
            <h3 className="text-right text-sm font-bold text-white/80">
              إدارة الطلاب ({filtered.length})
            </h3>
            <div className="flex min-w-0 flex-1 items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 sm:flex-none">
              <Search className="h-4 w-4 shrink-0 text-white/50" />
              <input
                dir="rtl"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ابحث بالاسم أو الرقم..."
                className="min-w-0 flex-1 bg-transparent text-sm text-white placeholder:text-white/30 outline-none sm:w-64 sm:flex-none"
              />
            </div>
          </div>
          <div className="max-h-[520px] overflow-y-auto pr-1">
            <ul className="space-y-2">
              {filtered.map((s) => {
                const z = zoneForPoints(s.points);
                return (
                  <li key={s.id}>
                    <div className="group flex w-full items-center justify-between gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-4 py-3 text-right transition hover:border-cyan-300/40 hover:bg-white/[0.06]">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setProfileStudent(s)}
                          title="عرض الملف الشخصي"
                          className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-cyan-300/30 bg-cyan-400/10 text-cyan-200 transition hover:bg-cyan-400/25"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <span
                          className="grid h-9 w-9 place-items-center rounded-full text-[11px] font-black"
                          style={{ background: z.color + "22", color: z.color, border: `1px solid ${z.color}66` }}
                        >
                          {s.points}
                        </span>
                        <span className="text-xs text-white/50" dir="ltr">
                          {s.username}
                        </span>
                      </div>
                      <button
                        onClick={() => setSelected(s)}
                        className="flex items-center gap-3 text-right"
                      >
                        <div>
                          <div className="text-sm font-bold text-white">{s.name}</div>
                          <div className="text-[11px] text-white/40" dir="ltr">
                            {s.admin_id}
                          </div>
                        </div>
                        <ChevronLeft className="h-4 w-4 text-white/40 transition group-hover:text-cyan-200" />
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>


      {/* Leaderboards */}
      <div className="relative z-10 mx-auto grid max-w-7xl gap-5 px-3 pb-16 sm:px-5 md:grid-cols-2">
        <Leaderboard
          title="TOP 10 GPA"
          subtitle="أعلى معدلات أكاديمية"
          accent="#38f0ff"
          items={[...list]
            .filter((s) => typeof s.gpa === "number")
            .sort((a, b) => (b.gpa ?? 0) - (a.gpa ?? 0))
            .slice(0, 10)
            .map((s) => ({
              student: s,
              value: (s.gpa ?? 0).toFixed(2),
              colorHint: "#ffd447",
            }))}
        />
        <Leaderboard
          title="TOP 10 POINTS"
          subtitle="أعلى النقاط السلوكية"
          accent="#ffd447"
          items={[...list]
            .sort((a, b) => b.points - a.points)
            .slice(0, 10)
            .map((s) => ({
              student: s,
              value: `${s.points}`,
              colorHint: zoneForPoints(s.points).color,
            }))}
        />
      </div>


      {selected && (
        <StudentControlPanel
          student={selected}
          onClose={() => setSelected(null)}
          onChanged={() => {}}
        />
      )}

      {profileStudent && (
        <StudentProfileModal student={profileStudent} onClose={() => setProfileStudent(null)} />
      )}

      {showActiveList && (
        <ActiveUsersModal
          usernames={activeUsers}
          students={list}
          onClose={() => setShowActiveList(false)}
        />
      )}
    </main>
  );
}

function StatCard({
  icon,
  label,
  value,
  accent,
  live,
  onEye,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  accent: string;
  live?: boolean;
  onEye?: () => void;
}) {
  return (
    <div className="glass-card relative overflow-hidden rounded-2xl p-5">
      <div className={`absolute inset-y-0 right-0 w-1.5 bg-gradient-to-b ${accent}`} />
      <div className="flex items-center justify-between">
        <div
          className={`grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br ${accent} text-[#031024]`}
        >
          {icon}
        </div>
        <div className="flex items-center gap-2">
          {live && (
            <span className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-300">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              LIVE
            </span>
          )}
          {onEye && (
            <button
              onClick={onEye}
              title="عرض القائمة"
              className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-emerald-300/30 bg-emerald-400/10 text-emerald-200 transition hover:bg-emerald-400/25"
            >
              <Eye className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
      <div className="mt-4 text-right">
        <div className="font-sans text-4xl font-black text-white text-glow" dir="ltr">
          {value}
        </div>
        <div className="mt-1 text-sm text-white/60">{label}</div>
      </div>
    </div>
  );
}

function StudentControlPanel({
  student,
  onClose,
  onChanged,
}: {
  student: Student;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [state, setState] = useState(() => getStudentState(student.id));
  const [delta, setDelta] = useState(1);
  const [op, setOp] = useState<"add" | "sub">("add");
  const [reason, setReason] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editDelta, setEditDelta] = useState(0);
  const [editReason, setEditReason] = useState("");

  const z = zoneForPoints(state.points);

  useEffect(() => {
    const refresh = () => setState(getStudentState(student.id));
    refresh();
    return subscribeState(refresh);
  }, [student.id]);

  const submit = async () => {
    if (!reason.trim()) return;
    const signed = op === "add" ? Math.abs(delta) : -Math.abs(delta);
    await addPointChange(student.id, signed, reason);
    setReason("");
    setDelta(1);
    onChanged();
  };

  const startEdit = (l: LogEntry) => {
    setEditingId(l.id);
    setEditDelta(l.delta);
    setEditReason(l.reason);
  };

  const saveEdit = async (id: string) => {
    await updateLog(student.id, id, { delta: editDelta, reason: editReason });
    setEditingId(null);
    onChanged();
  };

  const removeLog = async (id: string) => {
    await deleteLog(student.id, id);
    onChanged();
  };

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-md font-arabic"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="glass-card relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl p-6"
        style={{ boxShadow: `0 30px 80px -20px ${z.color}55` }}
      >
        <button
          onClick={onClose}
          className="absolute left-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70 hover:bg-white/10"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="flex items-center gap-4 pt-2">
          <div
            className="grid h-16 w-16 place-items-center rounded-2xl text-2xl font-black"
            style={{
              background: z.color + "22",
              color: z.color,
              border: `2px solid ${z.color}`,
              boxShadow: `0 0 25px ${z.color}55`,
            }}
          >
            {state.points}
          </div>
          <div className="flex-1 text-right">
            <div className="text-lg font-bold text-white">{student.name}</div>
            <div className="text-xs text-white/50" dir="ltr">
              {student.username} · {(student as any).admin_id ?? student.id}
            </div>
            <div
              className="mt-1 inline-block rounded-full px-2 py-0.5 text-[11px] font-bold"
              style={{ background: z.color + "22", color: z.color, border: `1px solid ${z.color}66` }}
            >
              {z.zone}
            </div>
          </div>
        </div>

        {/* Edit points */}
        <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
          <h4 className="mb-3 text-right text-sm font-bold text-white/80">تعديل النقاط</h4>
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex overflow-hidden rounded-xl border border-white/10">
              <button
                onClick={() => setOp("add")}
                className={`flex items-center gap-1 px-3 py-2 text-sm font-bold transition ${
                  op === "add" ? "bg-emerald-500/30 text-emerald-200" : "text-white/60"
                }`}
              >
                <Plus className="h-4 w-4" /> إضافة
              </button>
              <button
                onClick={() => setOp("sub")}
                className={`flex items-center gap-1 px-3 py-2 text-sm font-bold transition ${
                  op === "sub" ? "bg-red-500/30 text-red-200" : "text-white/60"
                }`}
              >
                <Minus className="h-4 w-4" /> خصم
              </button>
            </div>
            <input
              type="number"
              min={1}
              value={delta}
              onChange={(e) => setDelta(Math.max(1, parseInt(e.target.value || "1")))}
              className="w-20 rounded-xl border border-white/10 bg-white/[0.05] px-3 py-2 text-center text-sm text-white outline-none focus:border-cyan-300/50"
            />
            <input
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="السبب (مطلوب)"
              className="flex-1 rounded-xl border border-white/10 bg-white/[0.05] px-3 py-2 text-right text-sm text-white placeholder:text-white/30 outline-none focus:border-cyan-300/50"
            />
          </div>
          <button
            onClick={submit}
            disabled={!reason.trim()}
            className="mt-3 w-full rounded-xl gradient-brand px-4 py-3 text-sm font-bold text-[#031024] shadow-[0_10px_30px_-10px_rgba(56,240,255,.6)] transition active:scale-[.98] disabled:opacity-50"
          >
            تحديث النقاط
          </button>
        </div>

        {/* History */}
        <div className="mt-5">
          <h4 className="mb-3 text-right text-sm font-bold text-white/80">
            HISTORY ({state.logs.length})
          </h4>
          {state.logs.length === 0 ? (
            <div className="rounded-xl border border-dashed border-white/10 bg-white/[0.02] p-6 text-center text-sm text-white/40">
              لا توجد سجلات بعد
            </div>
          ) : (
            <ul className="space-y-2">
              {state.logs.map((l) => {
                const positive = l.delta > 0;
                const isEditing = editingId === l.id;
                return (
                  <li
                    key={l.id}
                    className="rounded-xl border border-white/10 bg-white/[0.03] p-3"
                  >
                    {isEditing ? (
                      <div className="flex flex-wrap items-center gap-2">
                        <input
                          type="number"
                          value={editDelta}
                          onChange={(e) => setEditDelta(parseInt(e.target.value || "0"))}
                          className="w-20 rounded-lg border border-white/10 bg-white/[0.05] px-2 py-1.5 text-center text-sm text-white outline-none"
                        />
                        <input
                          value={editReason}
                          onChange={(e) => setEditReason(e.target.value)}
                          className="flex-1 rounded-lg border border-white/10 bg-white/[0.05] px-2 py-1.5 text-right text-sm text-white outline-none"
                        />
                        <button
                          onClick={() => saveEdit(l.id)}
                          className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/30 text-emerald-200 hover:bg-emerald-500/40"
                          title="حفظ"
                        >
                          <Save className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-white/60 hover:bg-white/10"
                          title="إلغاء"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => removeLog(l.id)}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-red-500/20 text-red-300 hover:bg-red-500/30"
                            title="حذف"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => startEdit(l)}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-500/20 text-cyan-200 hover:bg-cyan-500/30"
                            title="تعديل"
                          >
                            <Pencil className="h-4 w-4" />
                          </button>
                          <span
                            className={`min-w-[54px] rounded-full px-2 py-0.5 text-center text-xs font-black ${
                              positive
                                ? "bg-emerald-500/20 text-emerald-300"
                                : "bg-red-500/20 text-red-300"
                            }`}
                          >
                            {positive ? "+" : ""}
                            {l.delta}
                          </span>
                        </div>
                        <div className="flex-1 text-right">
                          <div className="text-sm text-white">{l.reason}</div>
                          <div className="text-[11px] text-white/40" dir="ltr">
                            {l.date}
                          </div>
                        </div>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

function BgFx() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute -top-40 -left-40 h-[520px] w-[520px] rounded-full bg-[radial-gradient(circle_at_center,#22b8ff55,transparent_60%)] blur-3xl animate-float-slow" />
      <div className="absolute -bottom-40 -right-32 h-[560px] w-[560px] rounded-full bg-[radial-gradient(circle_at_center,#ffd44733,transparent_65%)] blur-3xl animate-float-slower" />
      <div
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.6) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage: "radial-gradient(ellipse at center, black 40%, transparent 75%)",
        }}
      />
    </div>
  );
}

type LbItem = { student: Student; value: string; colorHint: string };

function Leaderboard({
  title,
  subtitle,
  accent,
  items,
}: {
  title: string;
  subtitle: string;
  accent: string;
  items: LbItem[];
}) {
  const medal = ["#ffd447", "#d0d6df", "#c99060"];
  return (
    <div className="glass-card rounded-2xl p-5">
      <div className="mb-4 flex items-center justify-between">
        <div className="text-right">
          <div className="text-xs text-white/50">{subtitle}</div>
        </div>
        <div
          className="font-sans text-lg font-black tracking-[0.35em]"
          dir="ltr"
          style={{
            color: accent,
            textShadow: `0 0 18px ${accent}77`,
          }}
        >
          {title}
        </div>
      </div>

      {/* Podium (top 3) */}
      {items.length >= 3 && (
        <div className="mb-4 grid grid-cols-3 items-end gap-2">
          {[items[1], items[0], items[2]].map((it, idx) => {
            const rank = idx === 0 ? 2 : idx === 1 ? 1 : 3;
            const height = rank === 1 ? 96 : rank === 2 ? 74 : 58;
            const color = medal[rank - 1];
            return (
              <div key={it.student.id} className="flex flex-col items-center">
                <div
                  className="mb-2 grid h-12 w-12 place-items-center rounded-full text-sm font-black"
                  style={{
                    background: color + "22",
                    color,
                    border: `2px solid ${color}`,
                    boxShadow: `0 0 22px ${color}66`,
                  }}
                >
                  {it.value}
                </div>
                <div className="text-center text-[11px] font-bold text-white line-clamp-1">
                  {it.student.name.split(" ").slice(0, 2).join(" ")}
                </div>
                <div
                  className="mt-1 w-full rounded-t-lg text-center text-xs font-black text-[#031024]"
                  style={{
                    height,
                    background: `linear-gradient(180deg, ${color}, ${color}88)`,
                    boxShadow: `0 -6px 24px -6px ${color}88`,
                  }}
                >
                  <span className="mt-1 inline-block">#{rank}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Ranks 4–10 */}
      <ul className="space-y-1.5">
        {items.slice(3).map((it, i) => (
          <li
            key={it.student.id}
            className="flex items-center justify-between gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-3 py-2"
          >
            <span
              className="min-w-[46px] rounded-full px-2 py-0.5 text-center text-[11px] font-black"
              style={{
                background: it.colorHint + "22",
                color: it.colorHint,
                border: `1px solid ${it.colorHint}55`,
              }}
            >
              {it.value}
            </span>
            <div className="flex-1 text-right">
              <div className="text-sm font-semibold text-white line-clamp-1">
                {it.student.name}
              </div>
              <div className="text-[10px] text-white/40" dir="ltr">
                {it.student.username}
              </div>
            </div>
            <span className="text-xs font-black text-white/50">#{i + 4}</span>
          </li>
        ))}
        {items.length === 0 && (
          <li className="rounded-xl border border-dashed border-white/10 p-4 text-center text-xs text-white/40">
            لا توجد بيانات
          </li>
        )}
      </ul>
    </div>
  );
}


function StudentProfileModal({ student, onClose }: { student: Student; onClose: () => void }) {
  const z = zoneForPoints(student.points);
  const subjects = [
    "الرياضيات",
    "اللغة العربية",
    "اللغة الإنجليزية",
    "العلوم",
    "الدراسات الاجتماعية",
    "الحاسب الآلي",
  ];
  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-md font-arabic"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="glass-card relative max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-2xl p-6"
        style={{ boxShadow: `0 30px 80px -20px ${z.color}55` }}
      >
        <button
          onClick={onClose}
          className="absolute left-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70 hover:bg-white/10"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="flex items-center gap-4 pt-2">
          <div
            className="grid h-16 w-16 place-items-center rounded-2xl text-2xl font-black"
            style={{
              background: z.color + "22",
              color: z.color,
              border: `2px solid ${z.color}`,
              boxShadow: `0 0 25px ${z.color}55`,
            }}
          >
            {student.points}
          </div>
          <div className="flex-1 text-right">
            <div className="text-lg font-bold text-white">{student.name}</div>
            <div className="text-xs text-white/50" dir="ltr">
              {student.username} · {(student as any).admin_id ?? student.id}
            </div>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-3">
          <InfoCard label="الاسم الكامل" value={student.name} icon={<Users className="h-4 w-4" />} />
          <InfoCard label="السنة الدراسية" value="2025 / 2026" icon={<BookOpen className="h-4 w-4" />} />
          <InfoCard
            label="إجمالي النقاط"
            value={String(student.points)}
            icon={<Sparkles className="h-4 w-4" />}
            accent={z.color}
          />
          <InfoCard
            label="النطاق الحالي"
            value={z.zone}
            icon={<Activity className="h-4 w-4" />}
            accent={z.color}
          />
          <InfoCard
            label="المعدل الحالي (GPA)"
            value={student.gpa !== null ? student.gpa.toFixed(2) : "—"}
            icon={<GraduationCap className="h-4 w-4" />}
          />
          <InfoCard
            label="نسبة الحضور"
            value={`${student.attendance}%`}
            icon={<Activity className="h-4 w-4" />}
          />
        </div>

        <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
          <div className="mb-3 flex items-center justify-between">
            <h4 className="text-right text-sm font-bold text-white/80">المواد المسجلة</h4>
            <BookOpen className="h-4 w-4 text-cyan-200/70" />
          </div>
          <div className="flex flex-wrap gap-2">
            {subjects.map((s) => (
              <span
                key={s}
                className="rounded-full border border-cyan-300/25 bg-cyan-400/10 px-3 py-1 text-xs font-semibold text-cyan-100"
              >
                {s}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoCard({
  label,
  value,
  icon,
  accent,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  accent?: string;
}) {
  return (
    <div className="glass-card rounded-xl p-3">
      <div className="flex items-center justify-between text-white/50">
        <span className="text-[11px]">{label}</span>
        <span>{icon}</span>
      </div>
      <div
        className="mt-2 text-right font-sans text-lg font-black"
        style={{ color: accent ?? "#ffffff", textShadow: accent ? `0 0 12px ${accent}66` : undefined }}
      >
        {value}
      </div>
    </div>
  );
}

function ActiveUsersModal({
  usernames,
  students,
  onClose,
}: {
  usernames: string[];
  students: Student[];
  onClose: () => void;
}) {
  const rows = usernames.map((u) => {
    const s = students.find((x) => x.username.toLowerCase() === u.toLowerCase());
    return { username: u, student: s };
  });
  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-md font-arabic"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="glass-card relative max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl p-6"
      >
        <button
          onClick={onClose}
          className="absolute left-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70 hover:bg-white/10"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="mb-4 flex items-center gap-2 pt-1">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-400" />
          </span>
          <h3 className="text-lg font-bold text-white">المتصلون الآن ({rows.length})</h3>
        </div>
        {rows.length === 0 ? (
          <div className="rounded-xl border border-dashed border-white/10 p-8 text-center text-sm text-white/40">
            لا يوجد مستخدمون نشطون حالياً
          </div>
        ) : (
          <ul className="space-y-2">
            {rows.map(({ username, student }) => (
              <li
                key={username}
                className="flex items-center justify-between gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-4 py-3"
              >
                <span className="rounded-full border border-emerald-400/40 bg-emerald-400/10 px-2 py-0.5 text-[10px] font-black text-emerald-300">
                  LIVE
                </span>
                <div className="flex-1 text-right">
                  <div className="text-sm font-bold text-white">
                    {student ? student.name : username}
                  </div>
                  <div className="text-[11px] text-white/40" dir="ltr">
                    {username}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
