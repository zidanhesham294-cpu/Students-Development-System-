import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { clearCurrentStudent, getCurrentStudent, type Student } from "@/lib/auth";
import { SdsShell } from "./dashboard.index";
import { supabase } from "@/integrations/supabase/client";
import { getSessionToken } from "@/lib/auth";
import { submitAttendance } from "@/lib/sds.functions";
import { CheckCircle2, KeyRound, Loader2, XCircle, Inbox } from "lucide-react";

export const Route = createFileRoute("/dashboard/active")({
  component: ActivePage,
});

type HistoryRow = {
  id: string;
  session_id: string;
  status: string;
  marked_at: string | null;
  session_name: string;
  created_at: string;
};

function ActivePage() {
  const navigate = useNavigate();
  const [student, setStudent] = useState<Student | null>(null);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [lastSessionId, setLastSessionId] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryRow[]>([]);

  useEffect(() => {
    const s = getCurrentStudent();
    if (!s) navigate({ to: "/" });
    else setStudent(s);
  }, [navigate]);

  const loadHistory = async (sid: string) => {
    const { data } = await supabase
      .from("attendance_records")
      .select("id, session_id, status, marked_at, attendance_sessions(name, created_at)")
      .eq("student_id", sid)
      .order("created_at", { ascending: false })
      .limit(50);
    const rows = (data ?? []).map((r: {
      id: string;
      session_id: string;
      status: string;
      marked_at: string | null;
      attendance_sessions: { name: string; created_at: string } | null;
    }) => ({
      id: r.id,
      session_id: r.session_id,
      status: r.status,
      marked_at: r.marked_at,
      session_name: r.attendance_sessions?.name ?? "جلسة",
      created_at: r.attendance_sessions?.created_at ?? "",
    }));
    setHistory(rows);
  };

  useEffect(() => {
    if (!student) return;
    void loadHistory(student.id);
    const ch = supabase
      .channel(`sds-att-student-${student.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "attendance_records", filter: `student_id=eq.${student.id}` }, () => {
        void loadHistory(student.id);
      })
      .subscribe();
    return () => { void supabase.removeChannel(ch); };
  }, [student?.id]);

  const submit = async () => {
    if (!/^\d{6}$/.test(code)) {
      setMsg({ ok: false, text: "أدخل الكود المكون من 6 أرقام" });
      return;
    }
    setBusy(true);
    setMsg(null);
    try {
      const token = getSessionToken() ?? "";
      const res = await submitAttendance({ data: { token, code } });
      if (!res.ok) {
        setMsg({ ok: false, text: res.error });
      } else {
        setMsg({ ok: true, text: "تم تسجيل الحضور بنجاح" });
        setLastSessionId(res.sessionId);
      }
    } catch (e) {
      setMsg({ ok: false, text: (e as Error).message });
    } finally {
      setBusy(false);
    }
  };

  const locked = useMemo(() => !!lastSessionId, [lastSessionId]);

  if (!student) return null;
  return (
    <SdsShell
      studentName={student.name}
      backTo="/dashboard"
      onLogout={() => { clearCurrentStudent(); navigate({ to: "/" }); }}
    >
      <div className="mx-auto max-w-2xl px-5 pb-16 space-y-5">
        <div className="glass-card rounded-2xl p-6">
          <div className="mb-3 flex items-center gap-2 text-right">
            <KeyRound className="h-5 w-5 text-cyan-200" />
            <h3 className="text-sm font-bold text-white/90">أدخل كود الحضور الحالي</h3>
          </div>
          <div className="flex items-center gap-2">
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
              disabled={locked}
              inputMode="numeric"
              placeholder="------"
              className="flex-1 rounded-xl border border-white/10 bg-white/[0.05] px-4 py-4 text-center font-sans text-3xl tracking-[0.7em] text-white outline-none focus:border-cyan-300/60 disabled:opacity-60"
              dir="ltr"
            />
            <button
              onClick={submit}
              disabled={busy || locked || code.length !== 6}
              className="rounded-xl gradient-brand px-5 py-4 text-sm font-bold text-[#031024] shadow-[0_10px_30px_-10px_rgba(56,240,255,.6)] transition disabled:opacity-50"
            >
              {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : "تأكيد"}
            </button>
          </div>
          {msg && (
            <div className={`mt-3 flex items-center gap-2 rounded-xl px-3 py-2 text-sm ${msg.ok ? "bg-emerald-500/15 text-emerald-200 border border-emerald-400/30" : "bg-red-500/10 text-red-200 border border-red-400/30"}`}>
              {msg.ok ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
              <span>{msg.text}</span>
            </div>
          )}
        </div>

        <div>
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-sans text-lg font-black tracking-[0.3em] text-white text-glow" dir="ltr">HISTORY</h3>
            <span className="text-xs uppercase tracking-widest text-white/40" dir="ltr">Attendance</span>
          </div>
          {history.length === 0 ? (
            <div className="glass-card flex flex-col items-center justify-center gap-3 rounded-2xl px-6 py-14 text-center">
              <div className="grid h-14 w-14 place-items-center rounded-full border border-white/10 bg-white/5 text-white/50">
                <Inbox className="h-6 w-6" />
              </div>
              <p className="font-arabic text-sm text-white/60">لا توجد سجلات حضور بعد</p>
            </div>
          ) : (
            <ul className="glass-card space-y-2 rounded-2xl p-3">
              {history.map((h) => {
                const present = h.status === "present";
                return (
                  <li key={h.id} className="flex items-center justify-between gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-4 py-3">
                    <span className={`min-w-[64px] rounded-full px-2 py-0.5 text-center text-xs font-black ${present ? "bg-emerald-500/20 text-emerald-300" : "bg-red-500/20 text-red-300"}`}>
                      {present ? "حاضر" : "غائب"}
                    </span>
                    <div className="flex-1 text-right">
                      <div className="text-sm text-white">{h.session_name}</div>
                      <div className="text-[11px] text-white/40" dir="ltr">
                        {h.created_at ? new Date(h.created_at).toLocaleString("ar-EG") : ""}
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </SdsShell>
  );
}
