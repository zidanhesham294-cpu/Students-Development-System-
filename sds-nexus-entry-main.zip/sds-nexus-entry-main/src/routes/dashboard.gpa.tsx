import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getCurrentStudent, clearCurrentStudent, type Student } from "@/lib/auth";
import { SdsShell } from "./dashboard.index";

export const Route = createFileRoute("/dashboard/gpa")({
  component: GpaPage,
});

function GpaPage() {
  const navigate = useNavigate();
  const [student, setStudent] = useState<Student | null>(null);
  useEffect(() => {
    const s = getCurrentStudent();
    if (!s) navigate({ to: "/" });
    else setStudent(s);
  }, [navigate]);
  if (!student) return null;
  return (
    <SdsShell
      studentName={student.name}
      backTo="/dashboard"
      onLogout={() => { clearCurrentStudent(); navigate({ to: "/" }); }}
    >
      <div className="mx-auto max-w-2xl px-5 pb-16">
        <div className="glass-card rounded-2xl p-8 text-center">
          <div className="text-xs uppercase tracking-[0.4em] text-white/50">Academic GPA</div>
          <div className="mt-4 font-sans text-6xl font-black text-white text-glow tabular-nums">
            {student.gpa ?? "—.—"}
          </div>
          <p className="mt-2 text-sm text-white/60">
            {student.gpa ? "معدلك الأكاديمي الحالي" : "لم يتم إدخال المعدل بعد من قبل الدكاترة."}
          </p>
        </div>
      </div>
    </SdsShell>
  );
}
