import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import {
  GraduationCap,
  Target,
  CalendarCheck,
  ChevronLeft,
  LogOut,
  User,

  CalendarDays,
  BookOpen,
  KeyRound,
  X,
} from "lucide-react";
import { clearCurrentStudent, getCurrentStudent, zoneForPoints, type Student } from "@/lib/auth";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { useLiveStudent } from "@/hooks/useLiveStudent";
import { useActiveHeartbeat } from "@/hooks/useActiveHeartbeat";

export const Route = createFileRoute("/dashboard/")({
  component: DashboardPage,
});

function DashboardPage() {
  const navigate = useNavigate();
  const [sessionStudent, setSessionStudent] = useState<Student | null>(null);

  useEffect(() => {
    const s = getCurrentStudent();
    if (!s) navigate({ to: "/" });
    else setSessionStudent(s);
  }, [navigate]);

  const live = useLiveStudent(sessionStudent?.id);
  const student = live ?? sessionStudent;

  if (!student)
    return (
      <SdsShell>
        <div className="py-24 text-center text-white/60">جاري التحميل...</div>
      </SdsShell>
    );

  const z = zoneForPoints(student.points);


  return (
    <SdsShell
      studentName={student.name}
      onLogout={() => {
        clearCurrentStudent();
        navigate({ to: "/" });
      }}
    >
      <div className="mx-auto flex max-w-2xl flex-col gap-5 px-5 pb-16">
        <NavCard
          to="/dashboard/gpa"
          icon={<GraduationCap className="h-7 w-7" />}
          label="GPA"
          sub="متابعة المعدل الأكاديمي"
          accent="from-[#22b8ff] to-[#38f0ff]"
        />
        <NavCard
          to="/dashboard/points"
          icon={<Target className="h-7 w-7" />}
          label="POINT"
          sub="نظام النقاط السلوكي"
          accent="from-[#4aa8ff] to-[#22b8ff]"
          badge={
            <span
              className="rounded-full px-2 py-0.5 text-xs font-bold"
              style={{
                background: z.color + "22",
                color: z.color,
                border: `1px solid ${z.color}66`,
              }}
            >
              {student.points} · {z.zone}
            </span>
          }
        />
        <NavCard
          to="/dashboard/active"
          icon={<CalendarCheck className="h-7 w-7" />}
          label="ACTIVE"
          sub="سجل الحضور والانصراف"
          accent="from-[#22c55e] to-[#4ade80]"
          badge={
            <span className="rounded-full border border-emerald-400/40 bg-emerald-400/10 px-2 py-0.5 text-xs font-bold text-emerald-300">
              {student.attendance}%
            </span>
          }
        />
      </div>
    </SdsShell>
  );
}

function NavCard({
  to,
  icon,
  label,
  sub,
  accent,
  badge,
}: {
  to: string;
  icon: ReactNode;
  label: string;
  sub: string;
  accent: string;
  badge?: ReactNode;
}) {
  return (
    <Link
      to={to}
      className="glass-card group relative flex items-center gap-5 overflow-hidden rounded-2xl px-6 py-6 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_30px_80px_-30px_rgba(56,240,255,.45)]"
    >
      <div className={`absolute inset-y-0 right-0 w-1.5 bg-gradient-to-b ${accent} opacity-90`} />
      <div
        className={`grid h-14 w-14 place-items-center rounded-xl bg-gradient-to-br ${accent} text-[#031024] shadow-[0_10px_25px_-10px_rgba(56,240,255,.6)] transition group-hover:scale-105`}
      >
        {icon}
      </div>
      <div className="flex-1 text-right">
        <div className="font-sans text-2xl font-black tracking-wide text-white text-glow" dir="ltr">
          {label}
        </div>
        <div className="mt-1 text-sm text-white/60">{sub}</div>
      </div>
      {badge}
      <ChevronLeft className="h-5 w-5 text-white/40 transition group-hover:-translate-x-1 group-hover:text-cyan-200" />
    </Link>
  );
}

export function SdsShell({
  children,
  studentName,
  onLogout,
  backTo,
}: {
  children: ReactNode;
  studentName?: string;
  onLogout?: () => void;
  backTo?: string;
}) {
  const navigate = useNavigate();
  const [openSide, setOpenSide] = useState(false);
  const current = getCurrentStudent();
  useActiveHeartbeat(current?.username ?? null);


  return (
    <main
      dir="rtl"
      className="relative min-h-screen w-full overflow-hidden font-arabic text-white"
      style={{ background: "radial-gradient(ellipse at top, #12294a 0%, #0b192c 45%, #07122a 100%)" }}
    >
      <BgFx />
      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 pt-6 sm:px-6 sm:pt-8">
        {/* Right side (RTL first) → Profile */}
        <div className="flex shrink-0 items-center">
          <button
            onClick={() => setOpenSide(true)}
            aria-label="الملف الشخصي"
            className="group relative inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-gradient-to-br from-[#1e3e62] to-[#0b192c] text-white shadow-[0_10px_30px_-12px_rgba(56,240,255,.55)] transition hover:border-cyan-300/50 hover:from-[#22b8ff] hover:to-[#4aa8ff] hover:text-[#031024]"
          >
            <User className="h-5 w-5" />
            <span className="absolute -top-0.5 -left-0.5 h-2.5 w-2.5 rounded-full bg-cyan-300 shadow-[0_0_10px_#38f0ff]" />
          </button>
        </div>

        {/* Center brand */}
        <div className="min-w-0 font-sans text-3xl font-black tracking-[0.35em] text-white text-glow sm:text-5xl sm:tracking-[0.4em]" dir="ltr">
          SDS
        </div>

        {/* Left side (RTL last) → Back / Logout */}
        <div className="flex shrink-0 items-center gap-2">
          {backTo ? (
            <button
              onClick={() => navigate({ to: backTo })}
              aria-label="رجوع"
              className="group inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/80 backdrop-blur-md transition hover:border-cyan-300/50 hover:bg-white/10 hover:text-cyan-200"
            >
              <ChevronLeft className="h-5 w-5 transition group-hover:-translate-x-0.5" />
            </button>
          ) : (
            onLogout && (
              <button
                onClick={onLogout}
                className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs text-white/70 backdrop-blur-md transition hover:bg-white/10 hover:text-white sm:px-4 sm:text-sm"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline" dir="rtl">خروج</span>
              </button>
            )
          )}
        </div>
      </header>

      {studentName && (
        <section className="relative z-10 mx-auto max-w-2xl px-5 pt-8 pb-6">
          <div className="glass-card rounded-2xl px-6 py-5 text-center">
            <p className="font-arabic text-sm font-light tracking-wide text-white/70">أهلاً</p>
            <p className="mt-1 font-arabic text-xl font-bold tracking-wide text-white text-glow">
              {studentName}
            </p>
          </div>
        </section>
      )}


      <div className="relative z-10 pt-2">{children}</div>

      {/* Right-slide profile sidebar (RTL: side="right" enters from right) */}
      <Sheet open={openSide} onOpenChange={setOpenSide}>
        <SheetContent
          side="right"
          className="w-[320px] border-l-0 border-r border-white/10 bg-gradient-to-b from-[#0b192c] via-[#0b192c]/95 to-[#07122a] p-0 text-white [&>button]:hidden"
        >
          <div dir="rtl" className="flex h-full flex-col font-arabic">
            <SheetHeader className="border-b border-white/10 p-5">
              <div className="flex items-center justify-between">
                <SheetTitle className="text-right text-lg font-bold text-white">
                  الملف الشخصي
                </SheetTitle>
                <button
                  onClick={() => setOpenSide(false)}
                  aria-label="إغلاق"
                  className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70 transition hover:bg-white/10 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              {studentName && (
                <div className="mt-3 flex items-center gap-3 text-right">
                  <div className="grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br from-[#22b8ff] to-[#4aa8ff] text-[#031024]">
                    <User className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-white">{studentName}</div>
                    <div className="text-xs text-white/50">طالب / SDS</div>
                  </div>
                </div>
              )}
            </SheetHeader>

            <nav className="flex-1 space-y-2 p-4">
              <SideLink icon={<CalendarDays className="h-5 w-5" />} label="الجدول الدراسي" />
              <SideLink icon={<BookOpen className="h-5 w-5" />} label="مواعيد الامتحانات" />
              <SideLink icon={<KeyRound className="h-5 w-5" />} label="تغيير كلمة المرور" />
            </nav>

            {onLogout && (
              <div className="border-t border-white/10 p-4">
                <button
                  onClick={() => {
                    setOpenSide(false);
                    onLogout();
                  }}
                  className="flex w-full items-center justify-between rounded-xl border border-red-400/30 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-200 transition hover:bg-red-500/20"
                >
                  <span>تسجيل الخروج</span>
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </main>
  );
}

function SideLink({ icon, label }: { icon: ReactNode; label: string }) {
  return (
    <button
      type="button"
      className="group flex w-full items-center justify-between gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-4 py-3 text-right text-sm text-white/80 transition hover:border-cyan-300/40 hover:bg-white/[0.06] hover:text-white"
    >
      <span className="flex items-center gap-3">
        <span className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-[#1e3e62] to-[#0b192c] text-cyan-200 transition group-hover:from-[#22b8ff] group-hover:to-[#4aa8ff] group-hover:text-[#031024]">
          {icon}
        </span>
        <span className="font-medium">{label}</span>
      </span>
      <ChevronLeft className="h-4 w-4 text-white/40 transition group-hover:-translate-x-0.5 group-hover:text-cyan-200" />
    </button>
  );
}

function BgFx() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute -top-40 -left-40 h-[520px] w-[520px] rounded-full bg-[radial-gradient(circle_at_center,#22b8ff55,transparent_60%)] blur-3xl animate-float-slow" />
      <div className="absolute -bottom-40 -right-32 h-[560px] w-[560px] rounded-full bg-[radial-gradient(circle_at_center,#1e3e6288,transparent_65%)] blur-3xl animate-float-slower" />
      <div
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.6) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage: "radial-gradient(ellipse at center, black 40%, transparent 75%)",
        }}
      />
    </div>
  );
}
