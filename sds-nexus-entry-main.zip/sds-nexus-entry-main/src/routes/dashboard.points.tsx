import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { clearCurrentStudent, getCurrentStudent, zoneForPoints, type Student } from "@/lib/auth";
import { SdsShell } from "./dashboard.index";
import { Inbox } from "lucide-react";
import { useLiveStudent } from "@/hooks/useLiveStudent";
import { getStudentState, subscribeState, type LogEntry } from "@/lib/adminStore";

export const Route = createFileRoute("/dashboard/points")({
  component: PointsPage,
});

function PointsPage() {
  const navigate = useNavigate();
  const [sessionStudent, setSessionStudent] = useState<Student | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);

  useEffect(() => {
    const s = getCurrentStudent();
    if (!s) navigate({ to: "/" });
    else setSessionStudent(s);
  }, [navigate]);

  const live = useLiveStudent(sessionStudent?.id);
  const student = live ?? sessionStudent;

  useEffect(() => {
    if (!student) return;
    const load = () => setLogs(getStudentState(student.id).logs);
    load();
    return subscribeState(load);
  }, [student?.id]);

  if (!student) return null;
  const points = student.points;
  const z = zoneForPoints(points);


  return (
    <SdsShell
      studentName={student.name}
      backTo="/dashboard"
      onLogout={() => {
        clearCurrentStudent();
        navigate({ to: "/" });
      }}
    >
      <div className="mx-auto flex max-w-2xl flex-col items-center px-5 pb-16">
        {/* Ring / Prestige disc */}
        <PointRing points={points} zone={z} />

        {/* Numeric */}
        <div className="mt-6 flex flex-col items-center">
          <div
            className="font-sans text-6xl font-black tabular-nums transition-all duration-500"
            style={{
              color: z.color,
              textShadow: z.prestige
                ? `0 0 24px ${z.color}, 0 0 48px ${z.color}`
                : `0 0 18px ${z.color}88`,
            }}
          >
            {points}
          </div>
          <div className="mt-1 text-xs uppercase tracking-[0.4em] text-white/50">Current Points</div>
        </div>

        {/* History */}
        <div className="mt-10 w-full">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-sans text-lg font-black tracking-[0.3em] text-white text-glow" dir="ltr">HISTORY</h3>
            <span className="text-xs uppercase tracking-widest text-white/40" dir="ltr">Timeline</span>
          </div>
          {logs.length === 0 ? (
            <div className="glass-card flex flex-col items-center justify-center gap-3 rounded-2xl px-6 py-14 text-center">
              <div className="grid h-14 w-14 place-items-center rounded-full border border-white/10 bg-white/5 text-white/50">
                <Inbox className="h-6 w-6" />
              </div>
              <p className="font-arabic text-sm text-white/60">لا توجد سجلات حالياً</p>
              <p className="font-arabic text-xs text-white/35">
                سيتم عرض حركات النقاط هنا عند توفرها
              </p>
            </div>
          ) : (
            <ul className="glass-card space-y-2 rounded-2xl p-3">
              {logs.map((l) => {
                const positive = l.delta > 0;
                return (
                  <li
                    key={l.id}
                    className="flex items-center justify-between gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-4 py-3"
                  >
                    <span
                      className={`min-w-[54px] rounded-full px-2 py-0.5 text-center text-xs font-black ${
                        positive
                          ? "bg-emerald-500/20 text-emerald-300"
                          : "bg-red-500/20 text-red-300"
                      }`}
                    >
                      {positive ? "+" : ""}
                      {l.delta}
                    </span>
                    <div className="flex-1 text-right">
                      <div className="text-sm text-white">{l.reason}</div>
                      <div className="text-[11px] text-white/40" dir="ltr">
                        {l.date}
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}

        </div>
      </div>
    </SdsShell>
  );
}

function PointRing({
  points,
  zone,
}: {
  points: number;
  zone: ReturnType<typeof zoneForPoints>;
}) {
  const size = 280;
  const stroke = 22;
  const r = (size - stroke) / 2;
  const cx = size / 2;
  const cy = size / 2;

  const segments = 10;
  // For prestige tiers the full ring is filled with gold; for standard tiers it
  // scales linearly with points/10.
  const filled = zone.prestige
    ? segments
    : Math.min(segments, Math.max(0, Math.round(points / 10)));
  const gap = 6;
  const totalGap = gap * segments;
  const segSpan = (360 - totalGap) / segments;
  const circumference = 2 * Math.PI * r;
  const segLen = (segSpan / 360) * circumference;

  const isShiny = zone.zone === "SHINY GOLD";
  const strokeColor = zone.color;

  return (
    <div className="relative mt-4" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="rotate-[-90deg]">
        {zone.prestige && (
          <defs>
            <linearGradient id="goldSeg" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fff2b8" />
              <stop offset="45%" stopColor={isShiny ? "#ffd447" : "#e6b53a"} />
              <stop offset="100%" stopColor="#c9902a" />
            </linearGradient>
          </defs>
        )}
        {/* Inner solid fill — white for standard, midnight for prestige */}
        <circle
          cx={cx}
          cy={cy}
          r={r - stroke / 2 - 2}
          fill={zone.prestige ? "#0b192c" : "#ffffff"}
        />
        {Array.from({ length: segments }).map((_, i) => {
          const isFilled = i < filled;
          const rotation = i * (segSpan + gap);
          const paint = zone.prestige
            ? "url(#goldSeg)"
            : isFilled
              ? strokeColor
              : "#000000";
          return (
            <circle
              key={i}
              cx={cx}
              cy={cy}
              r={r}
              fill="none"
              stroke={paint}
              strokeWidth={stroke}
              strokeDasharray={`${segLen} ${circumference - segLen}`}
              strokeDashoffset={-((rotation / 360) * circumference)}
              style={{
                filter: zone.prestige
                  ? isShiny
                    ? "drop-shadow(0 0 8px #ffe27a) drop-shadow(0 0 18px #ffb44a)"
                    : "drop-shadow(0 0 5px #e6b53acc)"
                  : isFilled
                    ? `drop-shadow(0 0 6px ${strokeColor}aa)`
                    : undefined,
              }}
            />
          );
        })}
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <div
          className="text-center font-sans font-black tracking-widest"
          style={
            zone.prestige
              ? {
                  color: "#ffffff",
                  fontSize: isShiny ? 26 : 30,
                  letterSpacing: "0.35em",
                  textShadow: isShiny
                    ? "0 0 8px #fff, 0 0 20px #fff, 0 0 42px #ffe27a, 0 0 72px #ffb44a"
                    : "0 0 6px #fff, 0 0 16px #fff2b0aa",
                }
              : { color: zone.color, fontSize: 40 }
          }
        >
          {zone.zone}
        </div>
      </div>
    </div>
  );
}
