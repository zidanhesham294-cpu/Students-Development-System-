import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent, type MouseEvent } from "react";
import { GraduationCap, BookOpen, ShieldCheck, User, Lock, Eye, EyeOff, Loader2, ArrowLeft, AlertCircle } from "lucide-react";
import { getCurrentUser, getRemember, setRemember, setSession } from "@/lib/auth";
import { login as loginFn } from "@/lib/sds.functions";

export const Route = createFileRoute("/")({
  component: LoginPage,
});

type Role = "student" | "teacher" | "admin";

const ROLES: { id: Role; label: string; icon: typeof GraduationCap; placeholder: string }[] = [
  { id: "student", label: "طالب", icon: GraduationCap, placeholder: "sds-2026-0001" },
  { id: "teacher", label: "معلم", icon: BookOpen, placeholder: "TEA-SDS-0001" },
  { id: "admin", label: "مدير", icon: ShieldCheck, placeholder: "ZIDAN-SDS-2026" },
];

function Particles() {
  const dots = useMemo(
    () =>
      Array.from({ length: 26 }, (_, i) => ({
        left: Math.random() * 100,
        size: 2 + Math.random() * 5,
        delay: -Math.random() * 20,
        duration: 18 + Math.random() * 22,
        opacity: 0.25 + Math.random() * 0.5,
        hue: Math.random() > 0.5 ? "#38f0ff" : "#4aa8ff",
      })),
    [],
  );
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute -top-40 -left-40 h-[520px] w-[520px] rounded-full bg-[radial-gradient(circle_at_center,#22b8ff55,transparent_60%)] blur-3xl animate-float-slow" />
      <div className="absolute -bottom-40 -right-32 h-[560px] w-[560px] rounded-full bg-[radial-gradient(circle_at_center,#1e3e6288,transparent_65%)] blur-3xl animate-float-slower" />
      <div className="absolute top-1/3 right-1/4 h-72 w-72 rounded-full bg-[radial-gradient(circle_at_center,#38f0ff33,transparent_70%)] blur-3xl animate-float-slow" />
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.6) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage: "radial-gradient(ellipse at center, black 40%, transparent 75%)",
        }}
      />
      {dots.map((d, i) => (
        <span
          key={i}
          className="absolute bottom-[-10%] rounded-full animate-drift"
          style={{
            left: `${d.left}%`,
            width: d.size,
            height: d.size,
            background: d.hue,
            boxShadow: `0 0 ${d.size * 3}px ${d.hue}`,
            opacity: d.opacity,
            animationDelay: `${d.delay}s`,
            animationDuration: `${d.duration}s`,
          }}
        />
      ))}
    </div>
  );
}

function LoginPage() {
  const navigate = useNavigate();
  const [role, setRole] = useState<Role>("student");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);
  const [remember, setRememberState] = useState<boolean>(() => (typeof window !== "undefined" ? getRemember() : false));

  useEffect(() => {
    if (typeof window === "undefined") return;
    const u = getCurrentUser();
    if (!u) return;
    if (u.role === "admin") navigate({ to: "/admin" });
    else if (u.role === "teacher") navigate({ to: "/teacher" });
    else if (getRemember()) navigate({ to: "/dashboard" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const current = ROLES.find((r) => r.id === role)!;
  const roleIndex = ROLES.findIndex((r) => r.id === role);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = (await loginFn({ data: { role, username: username.trim(), password: password.trim() } })) as
        | { error: string }
        | { token: string; role: "student" | "teacher" | "admin"; id?: string; name: string; username: string; student?: { id: string } };
      if ("error" in res) {
        setError(res.error);
        return;
      }
      setRemember(remember);
      const uid = res.student?.id ?? res.id ?? "";
      setSession(res.token, { id: uid, username: res.username, name: res.name, role: res.role });
      if (res.role === "admin") navigate({ to: "/admin" });
      else if (res.role === "teacher") navigate({ to: "/teacher" });
      else navigate({ to: "/dashboard" });
    } catch (err) {
      setError((err as Error).message || "تعذّر تسجيل الدخول");
    } finally {
      setLoading(false);
    }
  };

  const spawnRipple = (e: MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const id = Date.now();
    setRipples((r) => [...r, { id, x: e.clientX - rect.left, y: e.clientY - rect.top }]);
    setTimeout(() => setRipples((r) => r.filter((x) => x.id !== id)), 700);
  };

  return (
    <main
      dir="rtl"
      className="relative min-h-screen w-full overflow-hidden font-arabic text-white"
      style={{ background: "radial-gradient(ellipse at top, #12294a 0%, #0b192c 45%, #07122a 100%)" }}
    >
      <Particles />

      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-6 pt-8">
        <button className="group inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/70 backdrop-blur-md transition hover:bg-white/10 hover:text-white">
          <ArrowLeft className="h-4 w-4 transition group-hover:-translate-x-0.5" />
          <span dir="ltr">Back</span>
        </button>
        <div className="font-sans text-3xl font-black tracking-[0.35em] text-white/90 text-glow" dir="ltr">
          SDS
        </div>
        <div className="h-9 w-9" />
      </header>

      <section className="relative z-10 mx-auto flex min-h-[calc(100vh-8rem)] max-w-6xl items-center justify-center px-5 py-10">
        <div className="glass-card w-full max-w-[440px] rounded-3xl p-7 sm:p-9">
          <div className="mb-7 flex flex-col items-center text-center">
            <div className="relative mb-4">
              <div className="absolute inset-0 -z-10 rounded-2xl bg-[radial-gradient(circle,#38f0ff88,transparent_70%)] blur-xl" />
              <div className="neon-ring grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-[#0e2447] to-[#0a1730] font-sans text-3xl font-black text-white text-glow">
                S
              </div>
            </div>
            <h1
              className="font-sans text-[22px] font-semibold tracking-wide"
              style={{ background: "linear-gradient(90deg,#e8f6ff,#8fd6ff)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}
              dir="ltr"
            >
              Student Development System
            </h1>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="mb-2 block text-sm font-semibold text-white/80">تسجيل دخول</label>
              <div className="relative rounded-2xl border border-white/10 bg-white/[0.04] p-1.5 backdrop-blur-xl">
                <div
                  className="absolute inset-y-1.5 right-1.5 rounded-xl gradient-brand transition-all duration-500 ease-[cubic-bezier(.65,.05,.36,1)]"
                  style={{
                    width: "calc(100% - 12px)",
                    height: "calc((100% - 12px) / 3)",
                    transform: `translateY(${roleIndex * 100}%)`,
                    boxShadow: "0 10px 30px -10px rgba(56,240,255,.55), 0 0 0 1px rgba(255,255,255,.15) inset",
                  }}
                />
                <div className="relative flex flex-col">
                  {ROLES.map((r) => {
                    const Icon = r.icon;
                    const active = r.id === role;
                    return (
                      <button
                        type="button"
                        key={r.id}
                        onClick={() => setRole(r.id)}
                        className={`flex items-center justify-between rounded-xl px-4 py-3.5 text-right transition-colors duration-300 ${
                          active ? "text-white" : "text-white/60 hover:text-white/90"
                        }`}
                      >
                        <Icon className={`h-5 w-5 transition ${active ? "text-white drop-shadow-[0_0_8px_rgba(255,255,255,.7)]" : "text-cyan-200/70"}`} />
                        <span className="text-base font-semibold">{r.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            <FloatField icon={<User className="h-4 w-4" />} label="اسم المستخدم" value={username} onChange={setUsername} placeholder={current.placeholder} dir="ltr" />
            <FloatField
              icon={<Lock className="h-4 w-4" />}
              label="كلمة المرور"
              value={password}
              onChange={setPassword}
              placeholder="••••••••"
              type={showPass ? "text" : "password"}
              dir="ltr"
              trailing={
                <button type="button" onClick={() => setShowPass((s) => !s)} className="text-white/50 transition hover:text-cyan-200" tabIndex={-1}>
                  {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              }
            />

            <div className="flex items-center justify-between text-xs">
              <a href="#" className="text-cyan-200/70 transition hover:text-cyan-100">نسيت كلمة المرور؟</a>
              <label className="flex cursor-pointer items-center gap-2 text-white/60">
                <input type="checkbox" className="peer sr-only" checked={remember} onChange={(e) => setRememberState(e.target.checked)} />
                <span className="grid h-4 w-4 place-items-center rounded border border-white/20 bg-white/5 transition peer-checked:border-cyan-300 peer-checked:bg-cyan-400/30">
                  <span className="h-1.5 w-1.5 rounded-sm bg-cyan-200 opacity-0 transition peer-checked:opacity-100" />
                </span>
                تذكرني
              </label>
            </div>

            {error && (
              <div className="flex items-center gap-2 rounded-xl border border-red-400/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              onClick={spawnRipple}
              disabled={loading}
              className="group relative mt-2 w-full overflow-hidden rounded-xl gradient-brand px-6 py-4 font-sans text-base font-bold text-[#031024] shadow-[0_18px_45px_-15px_rgba(56,240,255,.65)] transition active:scale-[.98] disabled:opacity-80"
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                {loading ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    <span dir="rtl" className="font-arabic">جاري التحقق...</span>
                  </>
                ) : (
                  <span dir="rtl" className="font-arabic">تسجيل الدخول</span>
                )}
              </span>
              <span className="absolute inset-0 -translate-x-full bg-[linear-gradient(90deg,transparent,rgba(255,255,255,.35),transparent)] transition-transform duration-700 group-hover:translate-x-full" />
              {ripples.map((r) => (
                <span
                  key={r.id}
                  className="pointer-events-none absolute h-24 w-24 rounded-full bg-white/40"
                  style={{ left: r.x - 48, top: r.y - 48, animation: "ripple .7s ease-out forwards" }}
                />
              ))}
            </button>
          </form>

          <p className="mt-6 text-center text-[11px] uppercase tracking-[0.3em] text-white/40" dir="ltr">
            Protected by SDS Secure Gateway
          </p>
        </div>
      </section>
    </main>
  );
}

function FloatField({
  icon,
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  dir,
  trailing,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  type?: string;
  dir?: "ltr" | "rtl";
  trailing?: React.ReactNode;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div>
      <label className="mb-2 block text-sm font-semibold text-white/80">{label}</label>
      <div
        className={`group relative flex items-center gap-3 rounded-xl border bg-white/[0.04] px-4 py-3 backdrop-blur-xl transition-all duration-300 ${
          focused ? "border-cyan-300/70 shadow-[0_0_0_3px_rgba(56,240,255,.15),0_0_24px_rgba(56,240,255,.35)]" : "border-white/10 hover:border-white/20"
        }`}
      >
        <span className={`transition ${focused ? "text-cyan-300" : "text-white/50"}`}>{icon}</span>
        <input
          type={type}
          dir={dir}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder={placeholder}
          className="flex-1 bg-transparent font-sans text-[15px] tracking-wide text-white placeholder:text-white/30 outline-none"
        />
        {trailing}
      </div>
    </div>
  );
}
