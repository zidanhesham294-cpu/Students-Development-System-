import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { LogOut, Users, KeyRound, History as HistoryIcon, Search, Plus, Eye, X, Check, Save, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { clearSession, getCurrentUser, getSessionToken, zoneForPoints, type Student } from "@/lib/auth";
import { getAllStudents, subscribeState } from "@/lib/adminStore";
import { useActiveHeartbeat } from "@/hooks/useActiveHeartbeat";
import {
  removeFromRoster,
  saveAttendanceSession,
  setRoster,
  startAttendanceSession,
} from "@/lib/sds.functions";

export const Route = createFileRoute("/teacher")({
  component: TeacherPage,
});

type TabKey = "students" | "active" | "history";

type AttSession = { id: string; teacher_id: string; name: string; code: string; is_active: boolean; created_at: string; closed_at: string | null };
type AttRecord = { id: string; session_id: string; student_id: string; status: string };

function TeacherPage() {
  const navigate = useNavigate();
  const [teacher, setTeacher] = useState<{ id: string; name: string; username: string } | null>(null);
  const [tab, setTab] = useState<TabKey>("students");

  useEffect(() => {
    const u = getCurrentUser();
    if (!u || u.role !== "teacher") { navigate({ to: "/" }); return; }
    if (u.id) {
      setTeacher({ id: u.id, name: u.name, username: u.username });
    } else {
      // Legacy session without id — force re-login
      navigate({ to: "/" });
    }
  }, [navigate]);

  useActiveHeartbeat(teacher?.username);

  const logout = () => { clearSession(); navigate({ to: "/" }); };

  if (!teacher) return <TeacherShell onLogout={logout}><div className="py-24 text-center text-white/60">جاري التحميل...</div></TeacherShell>;

  return (
    <TeacherShell name={teacher.name} onLogout={logout}>
      <div className="mx-auto max-w-4xl px-3 sm:px-5">
        <div className="mb-5 grid grid-cols-3 gap-1.5 rounded-2xl border border-white/10 bg-white/[0.04] p-1.5">
          <TabBtn active={tab === "students"} onClick={() => setTab("students")} icon={<Users className="h-4 w-4" />} label="STUDENTS" />
          <TabBtn active={tab === "active"} onClick={() => setTab("active")} icon={<KeyRound className="h-4 w-4" />} label="ACTIVE" />
          <TabBtn active={tab === "history"} onClick={() => setTab("history")} icon={<HistoryIcon className="h-4 w-4" />} label="HISTORY" />
        </div>
        {tab === "students" && <StudentsTab teacherId={teacher.id} />}
        {tab === "active" && <ActiveTab teacherId={teacher.id} />}
        {tab === "history" && <HistoryTab teacherId={teacher.id} />}
      </div>
    </TeacherShell>
  );
}

function TabBtn({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex min-w-0 items-center justify-center gap-1.5 rounded-xl px-2 py-2.5 text-[11px] font-bold tracking-[0.15em] transition sm:gap-2 sm:px-4 sm:py-3 sm:text-sm sm:tracking-[0.2em] ${active ? "gradient-brand text-[#031024] shadow-[0_10px_30px_-10px_rgba(56,240,255,.55)]" : "text-white/60 hover:text-white"}`}
      dir="ltr"
    >
      <span className="shrink-0">{icon}</span>
      <span className="truncate">{label}</span>
    </button>
  );
}

// ---------------- STUDENTS TAB ----------------
function StudentsTab({ teacherId }: { teacherId: string }) {
  const [rosterIds, setRosterIds] = useState<string[]>([]);
  const [all, setAll] = useState<Student[]>([]);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [profile, setProfile] = useState<Student | null>(null);

  useEffect(() => {
    const refresh = () => setAll(getAllStudents());
    refresh();
    return subscribeState(refresh);
  }, []);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from("teacher_roster").select("student_id").eq("teacher_id", teacherId);
      setRosterIds((data ?? []).map((r) => r.student_id));
    };
    void load();
    const ch = supabase.channel(`sds-roster-${teacherId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "teacher_roster", filter: `teacher_id=eq.${teacherId}` }, () => void load())
      .subscribe();
    return () => { void supabase.removeChannel(ch); };
  }, [teacherId]);

  const rosterStudents = useMemo(() => {
    const set = new Set(rosterIds);
    const q = query.trim().toLowerCase();
    return all.filter((s) => set.has(s.id)).filter((s) => !q || s.name.toLowerCase().includes(q) || s.username.toLowerCase().includes(q));
  }, [all, rosterIds, query]);

  return (
    <div className="glass-card rounded-2xl p-3 sm:p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <button onClick={() => setPickerOpen(true)} className="inline-flex shrink-0 items-center gap-2 rounded-xl gradient-brand px-4 py-2.5 text-sm font-bold text-[#031024]">
          <Plus className="h-4 w-4" /> إضافة طلاب
        </button>
        <div className="flex min-w-0 flex-1 items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 sm:flex-none">
          <Search className="h-4 w-4 shrink-0 text-white/50" />
          <input dir="rtl" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ابحث..." className="min-w-0 flex-1 bg-transparent text-sm text-white outline-none placeholder:text-white/30 sm:w-56 sm:flex-none" />
        </div>
      </div>
      {rosterStudents.length === 0 ? (
        <div className="rounded-xl border border-dashed border-white/10 p-8 text-center text-sm text-white/40">
          لا يوجد طلاب في قائمتك بعد
        </div>
      ) : (
        <ul className="space-y-2">
          {rosterStudents.map((s) => (
            <li key={s.id} className="flex items-center justify-between gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-4 py-3">
              <div className="flex items-center gap-2">
                <button onClick={() => setProfile(s)} className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-cyan-300/30 bg-cyan-400/10 text-cyan-200 hover:bg-cyan-400/25">
                  <Eye className="h-4 w-4" />
                </button>
                <button
                  onClick={async () => {
                    const token = getSessionToken() ?? "";
                    await removeFromRoster({ data: { token, studentId: s.id } });
                  }}
                  className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-red-400/30 bg-red-400/10 text-red-200 hover:bg-red-400/25"
                  title="إزالة"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="flex-1 text-right">
                <div className="text-sm font-bold text-white">{s.name}</div>
                <div className="text-[11px] text-white/40" dir="ltr">{s.username}</div>
              </div>
            </li>
          ))}
        </ul>
      )}

      {pickerOpen && <RosterPicker teacherId={teacherId} rosterIds={rosterIds} onClose={() => setPickerOpen(false)} />}
      {profile && <ProfileModal student={profile} onClose={() => setProfile(null)} />}
    </div>
  );
}

function RosterPicker({ teacherId, rosterIds, onClose }: { teacherId: string; rosterIds: string[]; onClose: () => void }) {
  const [all, setAll] = useState<Student[]>(getAllStudents());
  const [checked, setChecked] = useState<Set<string>>(new Set(rosterIds));
  const [q, setQ] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const refresh = () => setAll(getAllStudents());
    refresh();
    return subscribeState(refresh);
  }, []);

  const filtered = useMemo(() => {
    const qq = q.trim().toLowerCase();
    if (!qq) return all;
    return all.filter((s) => s.name.toLowerCase().includes(qq) || s.username.toLowerCase().includes(qq));
  }, [all, q]);

  const toggle = (id: string) => {
    const n = new Set(checked);
    if (n.has(id)) n.delete(id); else n.add(id);
    setChecked(n);
  };

  const done = async () => {
    setSaving(true);
    const token = getSessionToken() ?? "";
    // add newly checked
    const toAdd = Array.from(checked).filter((id) => !rosterIds.includes(id));
    if (toAdd.length > 0) await setRoster({ data: { token, studentIds: toAdd } });
    // remove unchecked
    const toRemove = rosterIds.filter((id) => !checked.has(id));
    for (const id of toRemove) await removeFromRoster({ data: { token, studentId: id } });
    setSaving(false);
    // teacherId not needed here, kept for signature clarity
    void teacherId;
    onClose();
  };

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/70 p-4 backdrop-blur-md font-arabic"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="glass-card relative my-auto flex max-h-[88dvh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl shadow-[0_40px_100px_-30px_rgba(56,240,255,.35)]"
      >
        {/* Sticky header with title + search */}
        <div className="sticky top-0 z-10 border-b border-white/10 bg-[#0b192c]/85 px-5 pt-5 pb-4 backdrop-blur-xl">
          <div className="mb-3 flex items-center justify-between gap-3">
            <button
              onClick={onClose}
              aria-label="إغلاق"
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70 transition hover:bg-white/10 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
            <h3 className="text-right text-base font-bold text-white sm:text-lg">
              اختر الطلاب <span className="text-cyan-200">({checked.size})</span>
            </h3>
          </div>
          <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.05] px-3 py-2.5 focus-within:border-cyan-300/60">
            <Search className="h-4 w-4 shrink-0 text-white/50" />
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحث بالاسم أو رقم الطالب..."
              className="min-w-0 flex-1 bg-transparent text-sm text-white outline-none placeholder:text-white/40"
            />
            {q && (
              <button onClick={() => setQ("")} className="text-white/40 hover:text-white" aria-label="مسح">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <div className="mt-2 text-right text-[11px] text-white/40">
            {filtered.length} من {all.length} طالب
          </div>
        </div>

        {/* Scrollable list */}
        <div className="flex-1 overflow-y-auto px-4 py-3">
          <ul className="space-y-1.5">
            {filtered.map((s) => {
              const on = checked.has(s.id);
              return (
                <li
                  key={s.id}
                  onClick={() => toggle(s.id)}
                  className={`flex cursor-pointer items-center justify-between gap-3 rounded-xl border px-3 py-2.5 transition ${on ? "border-emerald-400/40 bg-emerald-500/10" : "border-white/5 bg-white/[0.02] hover:bg-white/[0.05]"}`}
                >
                  <span className={`grid h-6 w-6 shrink-0 place-items-center rounded-md border ${on ? "border-emerald-300 bg-emerald-400/30 text-emerald-100" : "border-white/20 bg-white/5"}`}>
                    {on && <Check className="h-4 w-4" />}
                  </span>
                  <div className="min-w-0 flex-1 text-right">
                    <div className="truncate text-sm font-semibold text-white">{s.name}</div>
                    <div className="truncate text-[11px] text-white/40" dir="ltr">{s.username}</div>
                  </div>
                </li>
              );
            })}
            {filtered.length === 0 && (
              <li className="rounded-xl border border-dashed border-white/10 p-6 text-center text-sm text-white/40">
                لا توجد نتائج
              </li>
            )}
          </ul>
        </div>

        {/* Sticky footer with action */}
        <div className="sticky bottom-0 border-t border-white/10 bg-[#0b192c]/85 p-4 backdrop-blur-xl">
          <button
            onClick={done}
            disabled={saving}
            className="w-full rounded-xl gradient-brand py-3.5 text-sm font-black tracking-[0.25em] text-[#031024] shadow-[0_10px_30px_-10px_rgba(56,240,255,.6)] transition active:scale-[.98] disabled:opacity-60"
            dir="ltr"
          >
            {saving ? <Loader2 className="mx-auto h-5 w-5 animate-spin" /> : "تم"}
          </button>
        </div>
      </div>
    </div>
  );
}

function ProfileModal({ student, onClose }: { student: Student; onClose: () => void }) {
  const z = zoneForPoints(student.points);
  return (
    <div dir="rtl" className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-md font-arabic" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="glass-card relative w-full max-w-md rounded-2xl p-6">
        <button onClick={onClose} className="absolute left-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white/70">
          <X className="h-4 w-4" />
        </button>
        <div className="flex items-center gap-4">
          <div className="grid h-16 w-16 place-items-center rounded-2xl text-2xl font-black" style={{ background: z.color + "22", color: z.color, border: `2px solid ${z.color}`, boxShadow: `0 0 25px ${z.color}55` }}>
            {student.points}
          </div>
          <div className="flex-1 text-right">
            <div className="text-lg font-bold text-white">{student.name}</div>
            <div className="text-xs text-white/50" dir="ltr">{student.username}</div>
            <div className="mt-1 inline-block rounded-full px-2 py-0.5 text-[11px] font-bold" style={{ background: z.color + "22", color: z.color, border: `1px solid ${z.color}66` }}>
              {z.zone}
            </div>
          </div>
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3 text-right text-sm">
          <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
            <div className="text-[11px] text-white/50">GPA</div>
            <div className="mt-1 font-black text-white">{student.gpa != null ? Number(student.gpa).toFixed(2) : "—"}</div>
          </div>
          <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
            <div className="text-[11px] text-white/50">الحضور</div>
            <div className="mt-1 font-black text-white">{student.attendance}%</div>
          </div>
        </div>
        <p className="mt-4 text-center text-[11px] text-white/40">عرض فقط — لا يمكنك تعديل بيانات الطالب.</p>
      </div>
    </div>
  );
}

// ---------------- ACTIVE TAB ----------------
function ActiveTab({ teacherId }: { teacherId: string }) {
  const [name, setName] = useState("");
  const [session, setSession] = useState<AttSession | null>(null);
  const [records, setRecords] = useState<AttRecord[]>([]);
  const [rosterStudents, setRosterStudents] = useState<Student[]>([]);
  const [starting, setStarting] = useState(false);
  const [all, setAll] = useState<Student[]>(getAllStudents());

  useEffect(() => {
    const refresh = () => setAll(getAllStudents());
    refresh();
    return subscribeState(refresh);
  }, []);

  // Load current active session, if any
  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from("attendance_sessions")
        .select("*").eq("teacher_id", teacherId).eq("is_active", true)
        .order("created_at", { ascending: false }).limit(1).maybeSingle();
      setSession((data ?? null) as AttSession | null);
    };
    void load();
  }, [teacherId]);

  // Load roster students
  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from("teacher_roster").select("student_id").eq("teacher_id", teacherId);
      const ids = new Set((data ?? []).map((r) => r.student_id));
      setRosterStudents(all.filter((s) => ids.has(s.id)));
    };
    void load();
  }, [teacherId, all]);

  // Subscribe to attendance records for current session
  useEffect(() => {
    if (!session) { setRecords([]); return; }
    const load = async () => {
      const { data } = await supabase.from("attendance_records").select("id, session_id, student_id, status").eq("session_id", session.id);
      setRecords((data ?? []) as AttRecord[]);
    };
    void load();
    const ch = supabase.channel(`sds-att-${session.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "attendance_records", filter: `session_id=eq.${session.id}` }, () => void load())
      .subscribe();
    return () => { void supabase.removeChannel(ch); };
  }, [session?.id]);

  const presentCount = records.filter((r) => r.status === "present").length;
  const absentCount = rosterStudents.length - presentCount;

  const start = async () => {
    if (!name.trim()) return;
    setStarting(true);
    const token = getSessionToken() ?? "";
    const res = await startAttendanceSession({ data: { token, name: name.trim() } });
    if (res.ok) setSession(res.session as AttSession);
    setStarting(false);
  };

  const save = async () => {
    if (!session) return;
    const token = getSessionToken() ?? "";
    await saveAttendanceSession({ data: { token, sessionId: session.id } });
    setSession(null);
    setName("");
  };

  const statusFor = (studentId: string) => records.find((r) => r.student_id === studentId)?.status ?? "absent";

  return (
    <div className="space-y-4">
      <div className="glass-card rounded-2xl p-5">
        <label className="mb-2 block text-right text-sm font-bold text-white/80">اسم المحاضرة أو السكشن</label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          disabled={!!session}
          placeholder="مثال: محاضرة الأحد 9 ص"
          className="w-full rounded-xl border border-white/10 bg-white/[0.05] px-4 py-3 text-right text-white outline-none focus:border-cyan-300/60 disabled:opacity-60"
        />
      </div>

      <div className="glass-card rounded-2xl p-5 text-center">
        {!session ? (
          <button onClick={start} disabled={starting || !name.trim()} className="mx-auto inline-flex items-center gap-2 rounded-xl gradient-brand px-6 py-4 text-sm font-bold text-[#031024] disabled:opacity-60">
            {starting ? <Loader2 className="h-5 w-5 animate-spin" /> : <KeyRound className="h-5 w-5" />}
            بدء جلسة الحضور (CODE)
          </button>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <div className="text-xs uppercase tracking-[0.4em] text-white/50" dir="ltr">Session Code</div>
            <div className="font-sans text-6xl font-black tracking-[0.4em] text-cyan-200 text-glow" dir="ltr">{session.code}</div>
            <div className="text-xs text-white/50">مشاركة هذا الكود مع الطلاب</div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="glass-card rounded-2xl p-4 text-center">
          <div className="text-xs text-white/50">عدد الحضور</div>
          <div className="mt-2 font-sans text-3xl font-black text-emerald-300">{presentCount}</div>
        </div>
        <div className="glass-card rounded-2xl p-4 text-center">
          <div className="text-xs text-white/50">عدد الغياب</div>
          <div className="mt-2 font-sans text-3xl font-black text-red-300">{absentCount}</div>
        </div>
      </div>

      <div className="glass-card rounded-2xl p-4">
        {rosterStudents.length === 0 ? (
          <div className="p-4 text-center text-sm text-white/40">أضف طلاباً إلى قائمتك من تبويب STUDENTS أولاً</div>
        ) : (
          <ul className="space-y-2">
            {rosterStudents.map((s) => {
              const present = statusFor(s.id) === "present";
              return (
                <li key={s.id} className="flex items-center justify-between gap-3 rounded-xl border border-white/5 bg-white/[0.03] px-4 py-3">
                  {present ? (
                    <span className="grid h-9 w-9 place-items-center rounded-lg bg-emerald-500/25 text-emerald-200">
                      <CheckCircle2 className="h-5 w-5" />
                    </span>
                  ) : (
                    <span className="grid h-9 w-9 place-items-center rounded-lg bg-red-500/25 text-red-200">
                      <XCircle className="h-5 w-5" />
                    </span>
                  )}
                  <div className="flex-1 text-right">
                    <div className="text-sm font-bold text-white">{s.name}</div>
                    <div className="text-[11px] text-white/40" dir="ltr">{s.username}</div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      {session && (
        <button onClick={save} className="w-full rounded-xl gradient-brand py-4 text-sm font-bold text-[#031024]">
          <Save className="mx-auto mr-2 inline h-5 w-5" /> حفظ
        </button>
      )}
    </div>
  );
}

// ---------------- HISTORY TAB ----------------
function HistoryTab({ teacherId }: { teacherId: string }) {
  const [sessions, setSessions] = useState<AttSession[]>([]);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [records, setRecords] = useState<AttRecord[]>([]);
  const [all, setAll] = useState<Student[]>(getAllStudents());

  useEffect(() => {
    const refresh = () => setAll(getAllStudents());
    refresh();
    return subscribeState(refresh);
  }, []);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from("attendance_sessions")
        .select("*").eq("teacher_id", teacherId).eq("is_active", false)
        .order("created_at", { ascending: false });
      setSessions((data ?? []) as AttSession[]);
    };
    void load();
    const ch = supabase.channel(`sds-hist-${teacherId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "attendance_sessions", filter: `teacher_id=eq.${teacherId}` }, () => void load())
      .subscribe();
    return () => { void supabase.removeChannel(ch); };
  }, [teacherId]);

  useEffect(() => {
    if (!expanded) return;
    (async () => {
      const { data } = await supabase.from("attendance_records").select("id, session_id, student_id, status").eq("session_id", expanded);
      setRecords((data ?? []) as AttRecord[]);
    })();
  }, [expanded]);

  const nameFor = (id: string) => all.find((s) => s.id === id)?.name ?? "—";

  return (
    <div className="glass-card rounded-2xl p-5">
      {sessions.length === 0 ? (
        <div className="rounded-xl border border-dashed border-white/10 p-8 text-center text-sm text-white/40">
          لا توجد جلسات محفوظة بعد
        </div>
      ) : (
        <ul className="space-y-2">
          {sessions.map((s) => {
            const isOpen = expanded === s.id;
            const present = isOpen ? records.filter((r) => r.status === "present").length : null;
            return (
              <li key={s.id} className="rounded-xl border border-white/10 bg-white/[0.03]">
                <button onClick={() => setExpanded(isOpen ? null : s.id)} className="flex w-full items-center justify-between gap-3 px-4 py-3 text-right">
                  <span className="text-xs text-white/50" dir="ltr">{new Date(s.created_at).toLocaleString("ar-EG")}</span>
                  <span className="text-sm font-bold text-white">{s.name}</span>
                </button>
                {isOpen && (
                  <div className="border-t border-white/5 p-3">
                    <div className="mb-3 flex justify-between gap-2 text-xs text-white/60">
                      <span className="rounded-full bg-red-500/15 px-2 py-1 text-red-200">غياب: {records.length - (present ?? 0)}</span>
                      <span className="rounded-full bg-emerald-500/15 px-2 py-1 text-emerald-200">حضور: {present}</span>
                    </div>
                    <ul className="space-y-1.5">
                      {records.map((r) => {
                        const isP = r.status === "present";
                        return (
                          <li key={r.id} className="flex items-center justify-between gap-3 rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
                            {isP ? <CheckCircle2 className="h-4 w-4 text-emerald-300" /> : <XCircle className="h-4 w-4 text-red-300" />}
                            <span className="flex-1 text-right text-sm text-white">{nameFor(r.student_id)}</span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

// ---------------- SHELL ----------------
function TeacherShell({ children, name, onLogout }: { children: React.ReactNode; name?: string; onLogout: () => void }) {
  return (
    <main dir="rtl" className="relative min-h-screen w-full overflow-hidden font-arabic text-white" style={{ background: "radial-gradient(ellipse at top, #12294a 0%, #0b192c 45%, #07122a 100%)" }}>
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -left-40 h-[520px] w-[520px] rounded-full bg-[radial-gradient(circle_at_center,#22b8ff55,transparent_60%)] blur-3xl animate-float-slow" />
        <div className="absolute -bottom-40 -right-32 h-[560px] w-[560px] rounded-full bg-[radial-gradient(circle_at_center,#4aa8ff55,transparent_65%)] blur-3xl animate-float-slower" />
      </div>

      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 pt-6 sm:px-6 sm:pt-8">
        <div className="w-10 shrink-0 sm:w-24" />
        <div className="min-w-0 text-center">
          <div className="font-sans text-2xl font-black tracking-[0.35em] text-white text-glow sm:text-4xl sm:tracking-[0.4em]" dir="ltr">SDS</div>
          {name && <div className="mt-1 truncate font-arabic text-sm font-bold text-white sm:mt-2 sm:text-lg">أهلاً {name}</div>}
        </div>
        <div className="shrink-0 text-left sm:w-24">
          <button onClick={onLogout} className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs text-white/70 backdrop-blur-md transition hover:bg-white/10 hover:text-white sm:px-4 sm:text-sm">
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline">خروج</span>
          </button>
        </div>
      </header>

      <div className="relative z-10 pt-8 pb-16">{children}</div>
    </main>
  );
}
