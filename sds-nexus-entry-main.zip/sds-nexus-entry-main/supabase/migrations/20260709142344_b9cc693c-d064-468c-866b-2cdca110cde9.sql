
-- ============ STUDENTS ============
CREATE TABLE public.students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id text NOT NULL UNIQUE,
  name text NOT NULL,
  username text NOT NULL UNIQUE,
  password text NOT NULL,
  points integer NOT NULL DEFAULT 100,
  zone text NOT NULL DEFAULT 'GREEN',
  gpa numeric,
  attendance integer NOT NULL DEFAULT 100,
  subjects jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX students_username_idx ON public.students (username);
GRANT SELECT ON public.students TO anon, authenticated;
GRANT ALL ON public.students TO service_role;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
-- Public read of safe columns is fine (school internal). Writes only via service role.
CREATE POLICY "students read" ON public.students FOR SELECT USING (true);

-- ============ BEHAVIORAL LOGS (HISTORY) ============
CREATE TABLE public.behavioral_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  delta integer NOT NULL,
  reason text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX behavioral_logs_student_idx ON public.behavioral_logs (student_id, created_at DESC);
GRANT SELECT ON public.behavioral_logs TO anon, authenticated;
GRANT ALL ON public.behavioral_logs TO service_role;
ALTER TABLE public.behavioral_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "behavioral_logs read" ON public.behavioral_logs FOR SELECT USING (true);

-- ============ ADMINS ============
CREATE TABLE public.admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  username text NOT NULL UNIQUE,
  password text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.admins TO service_role;
ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;
-- No anon/authenticated policies: admins table is server-only.

-- ============ TEACHERS ============
CREATE TABLE public.teachers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  username text NOT NULL UNIQUE,
  password text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.teachers TO anon, authenticated;
GRANT ALL ON public.teachers TO service_role;
ALTER TABLE public.teachers ENABLE ROW LEVEL SECURITY;
-- Only expose safe columns via a view; base table SELECT locked.
CREATE POLICY "teachers no read" ON public.teachers FOR SELECT USING (false);
CREATE VIEW public.teachers_public WITH (security_invoker=on) AS
  SELECT id, name, username, created_at FROM public.teachers;
GRANT SELECT ON public.teachers_public TO anon, authenticated;

-- ============ TEACHER ROSTER ============
CREATE TABLE public.teacher_roster (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id uuid NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(teacher_id, student_id)
);
CREATE INDEX teacher_roster_teacher_idx ON public.teacher_roster (teacher_id);
CREATE INDEX teacher_roster_student_idx ON public.teacher_roster (student_id);
GRANT SELECT ON public.teacher_roster TO anon, authenticated;
GRANT ALL ON public.teacher_roster TO service_role;
ALTER TABLE public.teacher_roster ENABLE ROW LEVEL SECURITY;
CREATE POLICY "teacher_roster read" ON public.teacher_roster FOR SELECT USING (true);

-- ============ ATTENDANCE SESSIONS ============
CREATE TABLE public.attendance_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id uuid NOT NULL REFERENCES public.teachers(id) ON DELETE CASCADE,
  name text NOT NULL,
  code text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz
);
CREATE INDEX attendance_sessions_teacher_idx ON public.attendance_sessions (teacher_id, created_at DESC);
CREATE INDEX attendance_sessions_active_idx ON public.attendance_sessions (is_active) WHERE is_active = true;
GRANT SELECT ON public.attendance_sessions TO anon, authenticated;
GRANT ALL ON public.attendance_sessions TO service_role;
ALTER TABLE public.attendance_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "attendance_sessions read" ON public.attendance_sessions FOR SELECT USING (true);

-- ============ ATTENDANCE RECORDS ============
CREATE TABLE public.attendance_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.attendance_sessions(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'absent',
  marked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(session_id, student_id)
);
CREATE INDEX attendance_records_session_idx ON public.attendance_records (session_id);
CREATE INDEX attendance_records_student_idx ON public.attendance_records (student_id);
GRANT SELECT ON public.attendance_records TO anon, authenticated;
GRANT ALL ON public.attendance_records TO service_role;
ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;
CREATE POLICY "attendance_records read" ON public.attendance_records FOR SELECT USING (true);

-- ============ ACTIVE SESSIONS (heartbeat) ============
CREATE TABLE public.active_sessions (
  username text PRIMARY KEY,
  role text NOT NULL,
  name text,
  last_seen timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX active_sessions_last_seen_idx ON public.active_sessions (last_seen DESC);
GRANT SELECT ON public.active_sessions TO anon, authenticated;
GRANT ALL ON public.active_sessions TO service_role;
ALTER TABLE public.active_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "active_sessions read" ON public.active_sessions FOR SELECT USING (true);

-- ============ updated_at trigger for students ============
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
CREATE TRIGGER students_updated_at BEFORE UPDATE ON public.students
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============ REALTIME ============
ALTER PUBLICATION supabase_realtime ADD TABLE public.students;
ALTER PUBLICATION supabase_realtime ADD TABLE public.behavioral_logs;
ALTER PUBLICATION supabase_realtime ADD TABLE public.teacher_roster;
ALTER PUBLICATION supabase_realtime ADD TABLE public.attendance_sessions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.attendance_records;
ALTER PUBLICATION supabase_realtime ADD TABLE public.active_sessions;
